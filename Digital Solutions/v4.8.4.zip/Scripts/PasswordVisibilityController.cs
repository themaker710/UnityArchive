using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PasswordVisibilityController : MonoBehaviour
{
    public TextMeshProUGUI passwordText;
    public TMP_InputField passwordInput;

    public Button visibilityButton;
    public RawImage visibilityImage;

    public Texture2D visibleTexture;
    public Texture2D hiddenTexture;

    private void Start()
    {
        //Reset alpha & icon
        visibilityImage.color = new Color(visibilityImage.color.r, visibilityImage.color.g, visibilityImage.color.b, 0.9f);
        visibilityImage.texture = hiddenTexture;

        Debug.Log("Password is hidden");
    }

    private void OnMouseEnter()
    {
        //Fade out on mouseover
        StopAllCoroutines();
        StartCoroutine(AlphaFade(visibilityImage, 0.9f, 0.5f, 1.0f));

        Debug.Log("Mouse over");
    }
    private void OnMouseExit()
    {
        //Fade in on mouse exit
        StopAllCoroutines();
        StartCoroutine(AlphaFade(visibilityImage, 0.5f, 0.9f, 1.0f));

        //Prevent user editing in the visible state
        OnMouseUp();
    }

    private void OnMouseDown()
    {
        //Change Icon
        visibilityImage.texture = visibleTexture;
        
        //Show text
        passwordText.text = passwordInput.text;
    }

    private void OnMouseUp()
    {
        //Change Icon
        visibilityImage.texture = hiddenTexture;

        //Rehide text
        passwordText.text = new string('*', passwordInput.text.Length);
    }

    IEnumerator AlphaFade(RawImage image, float start, float end, float duration)
    {
        float counter = 0f;

        while (counter < duration)
        {
            //Add time since last frame (count up predictably and based on user performance)
            counter += Time.deltaTime;
            //Apply alpha lerp based on the time
            image.color = new Color(image.color.r, image.color.g, image.color.b, Mathf.Lerp(start, end, counter / duration));
            //Next Frame
            yield return null;
        }
    }
}
