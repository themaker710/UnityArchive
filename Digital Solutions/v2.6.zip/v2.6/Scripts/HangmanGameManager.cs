using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Data;

public class HangmanGameManager : MonoBehaviour
{
    public Text difficultyText;
    public Text underscoreText;

    IDataReader reader;


    Button[] btn = { };

    private int[] numWords = HangmanManager.numWords;
    private string[] displayStructure;
    private int difficulty = HangmanManager.difficulty;
    string word = "";

    private void Start()
    {
        //dbassist = GetComponent<DBManager>();
        btn = FindObjectsOfType<Button>();
        foreach (Button btn in btn)
        {
            btn.interactable = true;
         
        }
       

        foreach (int num in numWords)
        {
            Debug.Log(num);
        }
        BeginGame();
    }
    void BeginGame()
    {
        // 0 = All, 1 = Easy, 2 = Medium, 3 = Hard, 4 = Very Hard
        string[] difficulties = { "All", "Easy", "Medium", "Hard", "Very Hard" };
        Debug.Log("Game started with difficulty " + difficulties[difficulty]);
        difficultyText.text = difficulties[difficulty];

        IDbConnection dbcon = DBManager.InitiateConnection("/words.db");
        
        //Construct Query
        string query = $"SELECT ID, Word, Uses, Solves FROM (SELECT ID, Word, Uses, Solves, rank() OVER (ORDER BY ID) as 'Row' FROM \"Random Words\"";
        int rand = Random.Range(1, numWords[difficulty]);
        if (!(difficulty == 0)) query += $" WHERE Length = {difficulty + 3})";
        else query += ")";
        query += $" WHERE Row = {rand}";

        query = "SELECT ID, Word, Uses, Solves FROM (SELECT ID, Word, Uses, Solves, rank () OVER (ORDER BY ID) as Row1 FROM 'Random Words' WHERE Length = 5) WHERE Row1 = 12";
        query = "SELECT Word, Uses, Solves, rank () OVER (ORDER BY Word) asdgsd FROM 'Random Words' WHERE Length = 5";
        Debug.Log(rand);
        Debug.Log(query);

        //Run query and read+store result

        int id = 0, uses = 0, solves = 0;
        reader = DBManager.QueryDB(query, dbcon);
        while (reader.Read()) { id = reader.GetInt32(0);  word = reader.GetString(1); uses = reader.GetInt32(2); solves = reader.GetInt32(3); }
        //while (reader.Read()) { word = reader.GetString(0); }
        Debug.Log($"Word: {word}, Uses: {uses}, Solves: {solves}, ID: {id}");

        DBManager.CloseConnection(dbcon, reader);

        //UPDATE "Random Words" SET Uses = Uses + 1 WHERE ID = 1

        //Get random word in difficulty range
        //Generate dynamicly spaced letter spaces
        displayStructure = new string[word.Length];
        for (int i = 0; i < displayStructure.Length; i++)
        {
            if (i == displayStructure.Length) displayStructure[i] = "___";
            else displayStructure[i] = "___   ";
        }


        underscoreText.text = string.Join("", displayStructure);

        //Generate char array of word
        //Iterate the 
    }
    public void ButtonPressed(string letter)
    {
        Debug.Log(letter);
        foreach (Button btn in btn)
        {
            if (btn.name.ToUpper() == letter.ToUpper()) btn.interactable = false;
        }
        //Test if letter is in char array 
        //Consequence or successful letter
    }
    public void Restart()
    {
        SceneManager.LoadScene("Hangman");
    }
   

}
