using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;

public class ContactsController : MonoBehaviour
{
    Resolution screenRes;


    List<ContactPrefabManager> contactsList;
    
    GameObject contactPrefab;

    public GameObject scrollview;

    string query;

    public InputField searchField;

    public Canvas[] canvases;

    //View Contact Linking Elements

    public Text[] nameOccTexts;
    public Text[] birthdateTexts;
    public InputField notesInputField;
    public Text primaryDetailText;
    public Text addressText;

    internal Detail[] details;
    internal Address[] addresses;
    
    void Start()
    {
        //Set screen res
        screenRes = Screen.resolutions[Screen.resolutions.Length-1];
        Screen.SetResolution((screenRes.height / 16) * 9, screenRes.height, true);
        contactPrefab = Resources.Load<GameObject>("Prefabs/ContactRow");

        LoadContactRows();
    }
    //void LoadData()
    //{
    //    contacts = new List<Contact>();

    //    DBManager.InitiateConnection("productivity.db");

    //    DBManager.QueryDB("SELECT FirstName, Nickname, LastName, DOB, Company, Department, JobTitle, ContactID FROM Contact");

    //    while (DBManager.reader.Read())
    //    {
    //        Contact c = new Contact();
    //        c.fname = DBManager.reader.SafeGet<string>(0);
    //        c.nickname = DBManager.reader.SafeGet<string>(1);
    //        c.lname = DBManager.reader.SafeGet<string>(2);
    //        c.dob = System.DateTime.Parse(DBManager.reader.SafeGet<string>(3));
    //        c.company = DBManager.reader.SafeGet<string>(4);
    //        c.department = DBManager.reader.SafeGet<string>(5);
    //        c.position = DBManager.reader.SafeGet<string>(6);
    //        c.id = DBManager.reader.SafeGet<int>(7);
    //        contacts.Add(c);
    //    }




    //    for (int i = 0; i < contacts.Count; i++)
    //    {
    //        DBManager.QueryDB("SELECT Street1, Street2, State, PostCode, Country, Suburb, AddressID FROM Address WHERE ContactID = " + contacts[i].id);

    //        contacts[i].addresses = new List<Address>();

    //        while (DBManager.reader.Read())
    //        {
    //            Address a = new Address
    //            {
    //                street1 = DBManager.reader.SafeGet<string>(0),
    //                street2 = DBManager.reader.SafeGet<string>(1),
    //                state = DBManager.reader.SafeGet<string>(2),
    //                pcode = DBManager.reader.SafeGet<string>(3),
    //                country = DBManager.reader.SafeGet<string>(4),
    //                suburb = DBManager.reader.SafeGet<string>(5),
    //                id = DBManager.reader.SafeGet<int>(6)
    //            };
    //            contacts[i].addresses.Add(a);
    //        }

    //        DBManager.QueryDB("SELECT DetailID, TypeID, Contact FROM Details WHERE ContactID = " + contacts[i].id);

    //        contacts[i].details = new List<Detail>();

    //        while (DBManager.reader.Read())
    //        {
    //            Detail d = new Detail
    //            {
    //                id = DBManager.reader.SafeGet<int>(0),
    //                typeID = DBManager.reader.SafeGet<int>(1),
    //                value = DBManager.reader.SafeGet<string>(2)
    //            };
    //            contacts[i].details.Add(d);
    //        }

    //    }
    //    DBManager.CloseConnection();

    //}

    public void UpdateQuery()
    {
        query = searchField.text;
        query.Trim();
        if (string.IsNullOrWhiteSpace(query))
            query = "";
        
        LoadContactRows();
    }

    internal void DeleteContact(int id)
    {
        Debug.Log("Deleting contact with id: " + id);



        //DBManager.InitiateConnection("productivity.db");
        //Main Table
        //DBManager.QueryDB("DELETE FROM Contact WHERE ContactID = " + id);
        //Details Table
        //DBManager.QueryDB("DELETE FROM Details WHERE ContactID = " + id);
        //Address Table
        //DBManager.QueryDB("DELETE FROM Address WHERE ContactID = " + id);

        //DBManager.CloseConnection();


    }

    internal void LoadContact(int id)
    {
        Debug.Log("Loading contact with id: " + id);

        DBManager.InitiateConnection("productivity.db");

        //Switch View
        canvases[0].gameObject.SetActive(false);
        canvases[1].gameObject.SetActive(true);

        int pdetailid = 0;

        //Change text fields
        DBManager.QueryDB("SELECT FirstName, Nickname, LastName, OtherName, DOB, Company, Department, JobTitle, Notes, PrimaryDetailID FROM Contact WHERE ContactID = " + id);
        while (DBManager.reader.Read())
        {
            nameOccTexts[0].text = DBManager.reader.SafeGet<string>(0) + " " + DBManager.reader.SafeGet<string>(2);
            nameOccTexts[1].text = "'" + DBManager.reader.SafeGet<string>(1) + "' | " + DBManager.reader.SafeGet<string>(3);
            nameOccTexts[2].text = DBManager.reader.SafeGet<string>(7) + " in " + DBManager.reader.SafeGet<string>(6) + " at " + DBManager.reader.SafeGet<string>(5);
            System.DateTime dob = System.DateTime.ParseExact(DBManager.reader.SafeGet<string>(4), "dd/MM/yyyy", null);

            birthdateTexts[0].text = dob.ToString("d MMMM yyyy");
            //Total days divided by the statistical average # of days in the Gregorian Calendar Year, rounded (obv flawed method, will improve)
            birthdateTexts[1].text = (int)(System.DateTime.Now.Subtract(dob).Duration().TotalDays / 365.2425) + " years old";

            notesInputField.text = DBManager.reader.SafeGet<string>(8);

            pdetailid = DBManager.reader.SafeGet<int>(9);
        }

        DBManager.reader.Close();

        //Load and add contact details

        DBManager.QueryDB("SELECT Contact, DetailID, TypeTag FROM Details WHERE ContactID = " + id);

        while (DBManager.reader.Read())
        {
            //Set primary contact if it exists
            if(DBManager.reader.SafeGet<int>(1) == pdetailid)
            {
                primaryDetailText.text = DBManager.reader.SafeGet<string>(2) + ": " + DBManager.reader.SafeGet<string>(0);
                continue;
            }
            //Build array and list
        }
        DBManager.reader.Close();
        //Load contact addresses
        DBManager.QueryDB("SELECT Street1, Street2, Suburb, State, PostCode, Country, TypeTag FROM Address WHERE ContactID = " + id);

        while (DBManager.reader.Read())
        {
            Address a = new Address()
            {
                street1 = DBManager.reader.SafeGet<string>(0),
                street2 = DBManager.reader.SafeGet<string>(1),
                suburb = DBManager.reader.SafeGet<string>(2),
                state = DBManager.reader.SafeGet<string>(3),
                pcode = DBManager.reader.SafeGet<string>(4),
                country = DBManager.reader.SafeGet<string>(5),
                typeTag = DBManager.reader.SafeGet<string>(6)
            };
            //Temp
            addressText.text = a.value;

            //Add to array (list)
        }

        DBManager.CloseConnection();
    }

    void LoadContactRows()
    {
        //Remove any existing children
        foreach (Transform child in scrollview.transform)
            Destroy(child.gameObject);
        
        //Query DB
        DBManager.InitiateConnection("productivity.db");

        string q = $"SELECT FirstName, LastName, Nickname, ContactID FROM Contact WHERE " +
            $"FirstName LIKE \"%{query}%\" OR " +
            $"Nickname LIKE \"%{query}%\" OR " +
            $"LastName LIKE \"%{query}%\" OR " +
            $"OtherName LIKE \"%{query}%\" OR " +
            $"ContactID LIKE \"{query}\"";
        
        DBManager.QueryDB(q);

        contactsList = new List<ContactPrefabManager>();
        
        //Make prefab and assign values
        while (DBManager.reader.Read())
        {
            GameObject contactRow = Instantiate(contactPrefab, scrollview.transform);
            ContactPrefabManager cpm = contactRow.GetComponent<ContactPrefabManager>();
            cpm.PopulateFields(DBManager.reader.SafeGet<string>(0), DBManager.reader.SafeGet<string>(2), DBManager.reader.SafeGet<string>(1), DBManager.reader.SafeGet<int>(3), this);
            contactsList.Add(cpm);
        }

        DBManager.CloseConnection();
    }
    void Update()
    {
        //Profiling shows this reduces redundant calls inherent in GetKeyDown method.
        if (Input.anyKeyDown)
        {
            //UX Feature - Quick delete entire search string
            if (Input.GetKeyDown(KeyCode.Delete) && EventSystem.current.currentSelectedGameObject == searchField.gameObject)
            {
                searchField.text = "";
                UpdateQuery();
            }
        }
    }

    private void OnApplicationQuit()
    {
        //Reset Screen Resolution
        Screen.SetResolution(screenRes.width, screenRes.height, true);
    }
    public void MainMenu()
    {
        SceneManager.LoadScene("Main");
        
    }
}


[System.Serializable]
struct Address
{
    /// <summary>
    /// Preformatted address value, assuming Australian locale.
    /// </summary>
    public string value => string.Join("\n", string.Join(" ", street1, street2), string.Join(" ", suburb, pcode), string.Join(" ", state, country)).Trim();
    
    //Data
    internal string street1;
    internal string street2;
    internal string suburb;
    internal string state;
    internal string pcode;
    internal string country;

    internal string typeTag;
    internal int id;
}
[System.Serializable]
struct Detail
{
    internal string value;
    internal int typeTag;
    internal int id;
}

