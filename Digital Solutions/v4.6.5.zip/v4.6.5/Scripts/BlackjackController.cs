using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Audio;
using UnityEngine.SceneManagement;

public class BlackjackController : MonoBehaviour
{
    //Unity linking variables
    public GameObject optionsPanel;
    public GameObject pregameInput;
    public GameObject gameInput;
    public Text volumeText;
    public Text betText;
    public Text cashText;

    //Canvases
    public Canvas menuCanvas;
    public Canvas playCanvas;

    //Options interactables
    public Slider volSlider;
    public Toggle bettingToggle;
    public Toggle handValueToggle;

    //Game elements
    public Image[] chipImages;

    //Audio components
    public AudioSource cardAudio;
    public AudioMixer audioMixer;
    public AudioClip cardAudioClip;


    //General variables
    float vol = 1;

    bool bettingEnabled = true, showHandValue = true;

    //Card values
    string[] cardSuits = { "c", "d", "h", "s" };
    string[] cardValues = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };

    string[] cardsInOrder;

    string[] cardsShuffled;

    int cash = 1000, bet = 0;

    //<1000 - 5, 10, 20, 50, 100, 250
    //>1000 - 25, 50, 100, 250, 500, 1000
    //>2000 - 50, 100, 250, 500, 1000, 2000
    //>5000 - 100, 250, 500, 1000, 2000, 5000
    int[][] bettingOptions = { new int[] { 5, 10, 20, 50, 100, 250 }, new int[] { 25, 50, 100, 250, 500, 1000 }, new int[] { 50, 100, 250, 500, 1000, 2000 }, new int[] { 100, 250, 500, 1000, 2000, 5000 } };
    int howRich = 0;

    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("main script started");

        //Set option values from storage if present

        bettingEnabled = PlayerPrefs.GetInt("bettingEnabled") == 1 ? true : false;
        bettingToggle.isOn = bettingEnabled;

        showHandValue = PlayerPrefs.GetInt("showHandValue") == 1 ? true : false;
        handValueToggle.isOn = showHandValue;

        vol = PlayerPrefs.GetFloat("volume");
        volSlider.value = vol;
        ChangeVolume(vol);

        // Set cash amount
        if (PlayerPrefs.HasKey("cash"))
            cash = PlayerPrefs.GetInt("cash");


        //Initialize cards

        cardsInOrder = new string[52];
        cardsShuffled = new string[52];


        int c = 0;
        //For each suit
        foreach (string denomination in cardSuits)
        {
            //And each card value
            foreach (string value in cardValues)
            {
                //Add to the deck
                cardsInOrder[c] = value + denomination;
                c++;
            }
        }
    }

    public void InitializeGame()
    {
        //Start game
        Debug.Log("play button pressed");
        playCanvas.gameObject.SetActive(true);
        menuCanvas.gameObject.SetActive(false);

        pregameInput.SetActive(true);
        //gameInput.SetActive(false);

        //Change chips
        LoadChipImages();

        //Shuffle
        ShuffleCards();

        //Reset variables
        cashText.text = "$" + cash.ToString();
        betText.text = "$" + bet.ToString();
    }
    void LoadChipImages()
    {
        //Decide which chips to show
        howRich = cash switch
        {
            int n when n < 1000 => 0,
            int n when n >= 1000 && n <= 1999 => 1,
            int n when n >= 2000 && n <= 4999 => 2,
            int n when n >= 5000 => 3,
            _ => 0
        };

        //Show correct chips
        for (int i = 0; i < chipImages.Length; i++)
        {
            chipImages[i].sprite = Resources.Load<Sprite>($"Images/Blackjack/Chips/{bettingOptions[howRich][i]}"); 
        }

    }
    void ShuffleCards()
    {
        Debug.Log("Shuffling cards");

        //Populate/Reset array
        // This creates a pointer, which means both arrays are updated simulatneously 
        //cardsShuffled = cardsInOrder;

        cardsInOrder.CopyTo(cardsShuffled, 0);

        //Repeat 1000 times
        for (int i = 0; i < 1000; i++)
        {
            //Select two random cards
            int c1 = Random.Range(0, 52);
            int c2 = Random.Range(0, 52);

            //Switch them
            string c1v = cardsShuffled[c1];
            cardsShuffled[c1] = cardsShuffled[c2];
            cardsShuffled[c2] = c1v;
        }

        int c = 0;
        //Check how well the shuffle worked
        for (int i = 0; i < cardsShuffled.Length; i++)
        {
            if (cardsShuffled[i] == cardsInOrder[i]) c++;
            //Debug.Log(cardsShuffled[i]);
            //Debug.Log(cardsInOrder[i]);
        }

        Debug.Log($"Number of cards in the same spot: {c}");
    }
    public void ChipPressed(int pos, bool less)
    {
        int value = bettingOptions[howRich][pos];
        //right click removes
        if (less)
        {
            if (bet <= value)
            {
                cash += bet;
                bet = 0;
            }
            else
            {
                bet -= value;
                cash += value;
            }
        }
        else
        {
            if (cash >= value)
            {
                bet += value;
                cash -= value;
            }

        }
        //check if enough cash

        //Display
        betText.text = "$" + bet.ToString();
        cashText.text = "$" + cash.ToString();

    }
    

    public void Card()
    {

    }
    IEnumerator flipCard()
    {
        yield break;
    }
    IEnumerator spinCard(GameObject gameObjectToMove, Quaternion newRot, float duration)
    {
        Quaternion currentRot = gameObjectToMove.transform.rotation;

        float counter = 0;
        while (counter < duration)
        {
            counter += Time.deltaTime;
            gameObjectToMove.transform.rotation = Quaternion.Lerp(currentRot, newRot, counter / duration);
            yield return null;
        }
    }

    public void HomeButtonPressed()
    {
        //Remove money stored in bet
        cash += bet;
        bet = 0;
        //Go back to the main menu
        Debug.Log("home button pressed");
        playCanvas.gameObject.SetActive(false);
        menuCanvas.gameObject.SetActive(true);
    }

    public void OpenOptions()
    {
        //Open options panel
        Debug.Log("option button pressed");
        optionsPanel.SetActive(true);
    }
    public void CloseOptions()
    {
        //Save preferences over restarts
        PlayerPrefs.SetFloat("volume", vol);
        PlayerPrefs.SetInt("bettingEnabled", bettingToggle.isOn ? 1 : 0);
        PlayerPrefs.SetInt("showHandValue", handValueToggle.isOn ? 1 : 0);

        //Disable panel
        optionsPanel.SetActive(false);
    }

    public void ChangeVolume(float sliderValue)
    {
        //Change actual game volume - Log used to match volume scaling (not linear)
        audioMixer.SetFloat("masterVol", Mathf.Log10(sliderValue) * 20);

        //Update internal variable
        vol = sliderValue;

        //Display volume as percentage
        volumeText.text = Mathf.RoundToInt(sliderValue * 100).ToString() + "%";
    }

    //***FIX**** Only partially working
    public void MuteAudio(bool mute)
    {
        Debug.Log(mute);

        if (mute)
        {
            audioMixer.SetFloat("masterVol", 0);
            volumeText.text = "0%";
            volSlider.value = 0;
        }
        else
        {
            audioMixer.SetFloat("masterVol", Mathf.Log10(vol) * 20);
            volSlider.value = vol;
            volumeText.text = Mathf.RoundToInt(vol * 100).ToString() + "%";
        }
    }

    //Test add money
    public void AddCash(int howMuch)
    {
        cash += howMuch;
        cashText.text = "$" + cashText.text;
    }

    //Test sound
    public void PlaySound()
    {
        StartCoroutine("cardDeal");
    }

    IEnumerator cardDeal()
    {
        for (int i = 0; i < 5; i++)
        {
            cardAudio.PlayOneShot(cardAudioClip);
            yield return new WaitForSeconds(0.35f);
        }

    }
    private void OnApplicationQuit()
    {
        PlayerPrefs.SetInt("cash", cash);
    }
    public void MainMenu()
    {
        PlayerPrefs.SetInt("cash", cash);
        PlayerPrefs.Save();
        SceneManager.LoadScene("Main");
    }
}
