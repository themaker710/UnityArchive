using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class BlackjackController : MonoBehaviour
{
    public GameObject optionsPanel;


    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("main script started");
    }


    public void PlayButtonPressed()
    {
        Debug.Log("play button pressed");
    }

    public void OpenOptions()
    {
        Debug.Log("option button pressed");

        optionsPanel.SetActive(true);
    }
    public void CloseOptions()
    {


        optionsPanel.SetActive(false);
    }
    public void MainMenu()
    {
        SceneManager.LoadScene("Main");
    }
}
