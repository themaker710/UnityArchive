using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;

public class ContactsController : MonoBehaviour
{
    Resolution screenRes;


    List<ContactPrefabManager> contactsList;
    
    GameObject contactPrefab;

    public GameObject scrollview;

    string query;

    public InputField searchField;
    
    void Start()
    {
        //Set screen res
        screenRes = Screen.resolutions[Screen.resolutions.Length-1];
        Screen.SetResolution((screenRes.height / 16) * 9, screenRes.height, true);
        contactPrefab = Resources.Load<GameObject>("Prefabs/ContactRow");

        LoadContactRows();
    }
    //void LoadData()
    //{
    //    contacts = new List<Contact>();

    //    DBManager.InitiateConnection("productivity.db");

    //    DBManager.QueryDB("SELECT FirstName, Nickname, LastName, DOB, Company, Department, JobTitle, ContactID FROM Contact");

    //    while (DBManager.reader.Read())
    //    {
    //        Contact c = new Contact();
    //        c.fname = DBManager.reader.SafeGet<string>(0);
    //        c.nickname = DBManager.reader.SafeGet<string>(1);
    //        c.lname = DBManager.reader.SafeGet<string>(2);
    //        c.dob = System.DateTime.Parse(DBManager.reader.SafeGet<string>(3));
    //        c.company = DBManager.reader.SafeGet<string>(4);
    //        c.department = DBManager.reader.SafeGet<string>(5);
    //        c.position = DBManager.reader.SafeGet<string>(6);
    //        c.id = DBManager.reader.SafeGet<int>(7);
    //        contacts.Add(c);
    //    }




    //    for (int i = 0; i < contacts.Count; i++)
    //    {
    //        DBManager.QueryDB("SELECT Street1, Street2, State, PostCode, Country, Suburb, AddressID FROM Address WHERE ContactID = " + contacts[i].id);

    //        contacts[i].addresses = new List<Address>();

    //        while (DBManager.reader.Read())
    //        {
    //            Address a = new Address
    //            {
    //                street1 = DBManager.reader.SafeGet<string>(0),
    //                street2 = DBManager.reader.SafeGet<string>(1),
    //                state = DBManager.reader.SafeGet<string>(2),
    //                pcode = DBManager.reader.SafeGet<string>(3),
    //                country = DBManager.reader.SafeGet<string>(4),
    //                suburb = DBManager.reader.SafeGet<string>(5),
    //                id = DBManager.reader.SafeGet<int>(6)
    //            };
    //            contacts[i].addresses.Add(a);
    //        }

    //        DBManager.QueryDB("SELECT DetailID, TypeID, Contact FROM Details WHERE ContactID = " + contacts[i].id);

    //        contacts[i].details = new List<Detail>();

    //        while (DBManager.reader.Read())
    //        {
    //            Detail d = new Detail
    //            {
    //                id = DBManager.reader.SafeGet<int>(0),
    //                typeID = DBManager.reader.SafeGet<int>(1),
    //                value = DBManager.reader.SafeGet<string>(2)
    //            };
    //            contacts[i].details.Add(d);
    //        }

    //    }
    //    DBManager.CloseConnection();

    //}


    
    public void UpdateQuery()
    {
        query = searchField.text;
        query.Trim();
        if (string.IsNullOrWhiteSpace(query))
            query = "";
        
        LoadContactRows();
    }

    void LoadContactRows()
    {
        //Remove any existing children
        foreach (Transform child in scrollview.transform)
        {
            Destroy(child.gameObject);
        }
        
        //Query DB
        DBManager.InitiateConnection("productivity.db");

        string q = $"SELECT FirstName, LastName, Nickname, ContactID FROM Contact WHERE " +
            $"FirstName LIKE \"%{query}%\" OR " +
            $"Nickname LIKE \"%{query}%\" OR " +
            $"LastName LIKE \"%{query}%\" OR " +
            $"OtherName LIKE \"%{query}%\" OR " +
            $"ContactID LIKE \"{query}\"";
        
        DBManager.QueryDB(q);

        contactsList = new List<ContactPrefabManager>();
        
        //Make prefab and assign values
        while (DBManager.reader.Read())
        {
            GameObject contactRow = Instantiate(contactPrefab, scrollview.transform);
            ContactPrefabManager cpm = contactRow.GetComponent<ContactPrefabManager>();
            cpm.PopulateFields(DBManager.reader.SafeGet<string>(0), DBManager.reader.SafeGet<string>(2), DBManager.reader.SafeGet<string>(1), DBManager.reader.SafeGet<int>(3));
            contactsList.Add(cpm);
        }

        DBManager.CloseConnection();
    }
    void Update()
    {
        if (Input.anyKeyDown)
        {
            if (Input.GetKeyDown(KeyCode.Delete) && EventSystem.current.currentSelectedGameObject == searchField.gameObject)
            {
                searchField.text = "";
                UpdateQuery();
            }
        }
    }

    private void OnApplicationQuit()
    {
        //Reset Screen Resolution
        Screen.SetResolution(screenRes.width, screenRes.height, true);
    }
    public void MainMenu()
    {
        SceneManager.LoadScene("Main");
        
    }
}


[System.Serializable]
struct Address
{
    /// <summary>
    /// Preformatted address value, assuming Australian locale.
    /// </summary>
    public string value => string.Join(" ", street1, street2) + "\n" + string.Join(" ", suburb, state, pcode) + country.ToLower() == "australia" ? "" : $"\n{country}";
    
    //Data
    internal string street1;
    internal string street2;
    internal string suburb;
    internal string state;
    internal string pcode;
    internal string country;

    internal int id;
}
[System.Serializable]
struct Detail
{
    public string type => new string[] { "phone", "email", "social" }[this.typeID];
    internal string value;
    internal int typeID;
    internal int id;
}

