using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using UnityEngine;

//Internal allows namespace script access
internal static class Extensions
{
    /// <summary>
    /// Generic SafeGet retrieves variables from the database, however inserts the default value in case of a null field.
    /// </summary>
    /// <typeparam name="T">Type of variable retrieving.</typeparam>
    /// <param name="index">Position of variable in query</param>
    /// <returns>Generic return variable</returns>
    internal static T SafeGet<T>(this IDataReader reader, int index)
    {
        //Shorthand version
        //if (!reader.IsDBNull(index))
        //    return (T)reader.GetValue(index);
        //return default;

        //This version handles potential known errors and increases usability.
        if (!reader.IsDBNull(index))
        {
            object value = reader.GetValue(index);
            System.Type type = value.GetType();
            
            //NUMBER datatype stored as 'long' datatype in SQLite (i.e. Int64)
            if (type == typeof(long))
            {
                value = (int)(long)value;
                type = typeof(int);
            }

            if (type != typeof(T))
            {
                Debug.Log($"Specified data type {typeof(T)} was not returned, got {type} instead.");
                throw new System.FormatException("Type does not match retrieved data. Check type and try again");
            }
            else
                return (T)value;
        }
        Debug.Log($"Specified value null, returning default value for {typeof(T)}");
        return default;
    }
    internal static bool IsNullOrWhiteSpace(this string str)
    {
        return string.IsNullOrWhiteSpace(str);
    }
    internal static int IndexOf(this System.Array arr, object query)
    {
        return System.Array.IndexOf(arr, query);
    }
    internal static bool IsLetter(this char c)
    {
        return char.IsLetter(c);
    }
    //internal static string Join(this System.Array arr, string seperator)
    //{
    //    return string.Join(seperator, arr);
    //}
    internal static char ToUpper(this char c)
    {
        return char.ToUpper(c);
    }

    private static bool OpenPopUp1(string title, string content, string button1, string button2, GameObject parent, MonoBehaviour mono)
    {
        GameObject prefab = Resources.Load<GameObject>("Prefabs/PopupModal");
        GameObject go = GameObject.Instantiate(prefab, parent.transform);
        PopUpManager script = go.GetComponent<PopUpManager>();
        script.PopulateFields(title, content, button1, button2);

        Debug.Log("Popup initialized. Getting results...");
        return false;
    }
    private static IEnumerator OpenPopUpCoro(PopUpManager script, GameObject go)
    {
        bool? rtn = null;
        Coroutine c = script.StartCoroutine(script.GetResult((r) =>
        {
            rtn = r;

            GameObject.Destroy(go);

            Debug.Log("Results retrieved and modal closed. Returning");
        }));
        yield return new WaitUntil(() => rtn != null);

    }
    /// <summary>
    /// Opens customizable popup 
    /// </summary>
    /// <param name="title">Title for modal</param>
    /// <param name="content">Description for modal</param>
    /// <param name="button1">Confirmation button text</param>
    /// <param name="button2">Cancel button text</param>
    /// <param name="parent">Parent GameObject to instantiate in</param>
    /// <param name="mono">Instance of unity script for coroutines. Use <b>this</b> in most cases.</param>
    // /// <returns><b>Task&lt;bool&gt;</b> - Use .Result to get <b>bool</b></returns>
    /// <returns><b>bool</b></returns>
    private static bool OpenPopUp(string title, string content, string button1, string button2, GameObject parent, MonoBehaviour mono)
    {
        GameObject prefab = Resources.Load<GameObject>("Prefabs/PopupModal");
        GameObject go = GameObject.Instantiate(prefab, parent.transform);
        PopUpManager script = go.GetComponent<PopUpManager>();
        script.PopulateFields(title, content, button1, button2);

        Debug.Log("Popup initialized. Getting results...");

        bool? rtn = null;
        script.StartCoroutine(script.GetResult((r) =>
        {
            rtn = r;

            GameObject.Destroy(go);

            Debug.Log("Results retrieved and modal closed. Returning");

            //return r;
        }));
        return rtn ?? false;
        //var tcs = new System.Threading.Tasks.TaskCompletionSource<object>();

        //mono.StartCoroutine(
        //    tempCoroutine(
        //        script.GetResult(),
        //        () => tcs.TrySetResult(null)));

        //await tcs.Task;


        //GameObject.Destroy(go);

        // If null then nothing returned from coroutine
        //if (rtn == null)
        //{
        //    Debug.Log("PopUp result not recieved, returning false");
        //    return false;
        //}

        //Debug.Log("Results retrieved and modal closed. Returning");

        //return rtn.Value;

        //return false;   
    
    }
}
