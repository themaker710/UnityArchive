using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ContactPrefabManager : MonoBehaviour
{
    public Button removeButton;
    
    public Text nameText;

    internal int contactID;

    internal bool remove = false;

    internal void PopulateFields(string fname, string nick, string lname, int ID)
    {
        contactID = ID;

        string name = "";
        
        if (string.IsNullOrEmpty(nick))
            name = fname;
        else
            name = nick;

        nameText.text = name + " " + lname;
    }

    public void ToggleRemove()
    {
        remove = !remove;
        if (remove)
            removeButton.gameObject.SetActive(true);
        else
            removeButton.gameObject.SetActive(false);
    }

    public void OpenPage()
    {
        throw new System.NotImplementedException();    
    }

    public void DeleteEntry()
    {
        throw new System.NotImplementedException();    
    }
}
