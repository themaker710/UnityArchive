using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class PokemonRowController : MonoBehaviour
{
    public TMP_Text nameText;
    public TMP_Text costText;
    public TMP_Text statText;
    public TMP_Text genText;

    public RawImage pokemonImage;

    Pokemon p;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    internal void PopulateData(Pokemon pokemon)
    {
        p = pokemon;
        nameText.text = p.name;
        costText.text = "$"+ p.Cost.ToString();
        statText.text = p.StatTotal.ToString();
        genText.text = p.generation.ToString();

        pokemonImage.texture = p.texture;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
