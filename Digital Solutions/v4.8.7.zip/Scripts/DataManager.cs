using JetBrains.Annotations;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using DB = AsyncDBManager;

public class DataManager : MonoBehaviour
{
    string destPath;
    string dbPath;

    string[] sourcePaths, sourceFiles;

    string fileHash;

    public GameObject loadingScreen;
    public Image blur;
    public TMP_Text loadingText;
    public TMP_Text taskText;
    string currentTask;

    public ValemonController controller;

    int preferredSource = 0;

    public bool loading = true;

    void Start()
    {
        sourcePaths = new string[] { "http://10.64.116.12/12dis/Valemon/", "https://ihelensvaleshs.com/valemon/" };
        //sourcePaths = new string[] { "https://ihelensvaleshs.com/valemon/" };
        destPath = Application.persistentDataPath;

        StartCoroutine(LoadDataIndicator());

        fileHash = PlayerPrefs.GetString("FileHash", string.Empty);

        File.Delete(Path.Combine(destPath, "pokemon.csv.old"));

        //Rename current file to pokemon.old.csv for comparison 
        if (File.Exists(Path.Combine(destPath, "pokemon.csv")))
            File.Move(Path.Combine(destPath, "pokemon.csv"), Path.Combine(destPath, "pokemon.csv.old"));

        //Download and parse CSV file
        GetCSV("pokemon.csv");
    }


    public IEnumerator GetTexture(int id)
    {
        //Download texture 'id.jpg' from preferred source, then send it back through the callback
        string source = Path.Combine(sourcePaths[preferredSource], "sprites", id + ".png");

        using(UnityWebRequest uwr = UnityWebRequestTexture.GetTexture(source))
        {
            //After a sustained number of new connections, a X509 cert error is thrown. This automatically accepts any certificate.
            uwr.certificateHandler = new BypassCertificate();

            var op = uwr.SendWebRequest();

            while (!op.isDone)
            {
                yield return null;
            }

            if(uwr.result == UnityWebRequest.Result.Success)
            {
                var texture = DownloadHandlerTexture.GetContent(uwr);
                Debug.Log("Texture downloaded for pokemon " + id);
                controller.pokemon[id-1].texture = texture;
            }
            else
            {
                Debug.LogError("Texture retrieval failed for:\n" + source);
                Debug.LogError(uwr.error);
            }
        }
    }


    IEnumerator LoadDataIndicator()
    {
        //Show loadingScreen while data is being loaded

        loadingScreen.SetActive(true);

        StartCoroutine(AnimateLoadText());

        while (loading)
        {
            taskText.text = currentTask;
            yield return null;
        }

        //Lower alpha to zero over 1 second
        while (blur.color.a > 0)
        {
            Color c = blur.color;
            c.a -= Time.deltaTime;
            c.a = Mathf.Clamp(c.a, 0, 1);
            blur.color = c;
            yield return null;
        }

        //Begin creation of pokemon array in memory. Occurs in the background
        controller.StartCoroutine(controller.LoadPokemon());

        loadingScreen.SetActive(false);

        StopCoroutine(nameof(AnimateLoadText));
    }
    IEnumerator AnimateLoadText()
    {
        //Animate dots on loading text every 0.5 seconds
        string dots = "";

        while (loading)
        {
            dots += ".";
            if (dots.Length > 3)
                dots = "";
            loadingText.text = "Loading" + dots;

            yield return new WaitForSeconds(0.5f);
        }
    }

    void GetCSV(string fileName)
    {
        //Determine source and destination paths
        string destFile = Path.Combine(destPath, fileName);

        currentTask = "Determining retrieval locations";
        sourceFiles = new string[sourcePaths.Length];

        for (int i = 0; i < sourceFiles.Length; i++)
            sourceFiles[i] = Path.Combine(sourcePaths[i], fileName);

        Debug.Log(destFile);

        //Start threaded web request
        StartCoroutine(IGetRequest(sourceFiles, destFile));
    }

    //Method will try initial value in source list, and if failed will try all subsequent options in order
    IEnumerator IGetRequest(string[] sources, string destFile, int sid = 0)
    {
        Debug.Log("Attempting to connect to " + sources[sid]);
        currentTask = "Attempting connection with Source " + (sid + 1);
        using (UnityWebRequest webRequest = UnityWebRequest.Get(sources[sid]))
        {
            // Request and wait for the desired page.
            webRequest.timeout = 5;
            var op = webRequest.SendWebRequest();
            Debug.Log("Start Download");

            //Wait for download to complete (or timeout)
            while (!op.isDone)
                yield return null;

            //Check for correct response
            if (webRequest.result == UnityWebRequest.Result.Success)
            {
                preferredSource = sid;
                Debug.Log("Download Succeeded");
                currentTask = "Downloaded file. Copying from buffer";
                //Save binary data to file
                FileStream stream = new FileStream(destFile, FileMode.Create);

                stream.Write(webRequest.downloadHandler.data, 0, webRequest.downloadHandler.data.Length);

                stream.Close();

                currentTask = "File saved";

                //Reaqcuire filename
                char[] separators = { '\\', '/' };
                string[] t = destFile.Split(separators);

                //Parse file into DB - FAILS HERE IF UNCOMMENTED
                //ParseCSV2(t[t.Length - 1]);

                ParseCSV(t[t.Length - 1]);
            }
            else
            {
                Debug.Log("Connection to server '" + sources[sid] + "' failed with error: ");
                currentTask = "Connection to Source " + (sid + 1) + " failed";
                Debug.LogError(webRequest.error);
                if (sid < sources.Length)
                    StartCoroutine(IGetRequest(sourceFiles, destFile, sid + 1));
                else
                    Debug.LogError("No more connections to try. Check the connection strings");
            }
        }
    }
    void ParseCSV(string fileName)
    {
        Debug.Log("File downloaded, parsing " + fileName);

        currentTask = "Calculating hash for " + fileName;
        string path = Path.Combine(destPath, fileName);

        string csvFile = Path.Combine(destPath, fileName);
        string oldFile = Path.Combine(destPath, fileName + ".old");

        //Minimum performance impact
        string newHash = Extensions.HashFile(path);

        Debug.Log(newHash + "\n" + fileHash);

        //For testing and algorithm confirmation purposes
        bool isForced = true;

        if ((fileHash != newHash) || isForced)
        {
            //Read all lines
            string[] records = File.ReadAllLines(csvFile);

            //Get filename without extension (range operator)
            string tableName = fileName[..^4].ToLower();

            //Get all headers
            string[] headers = records[0].Split(',');

            //Create table with headers
            CreateTable(tableName, headers);
            currentTask = "Parsing file";

            //Construct insert query for each row of values.
            string sql = "INSERT INTO " + tableName + " (ID, ";

            //Construct insert beginning
            for (int i = 1; i < headers.Length; i++)
            {
                sql += headers[i];

                if (i < headers.Length - 1)
                    sql += ", ";
            }
            sql += ") VALUES (";


            //Append data for each line
            for (int i = 1; i < records.Length; i++)
            {
                //Get values
                string insertQuery = sql;
                string[] values = records[i].Split(',');

                //Add the ID as an int
                insertQuery += values[0] + ", ";

                //Add the rest as a string
                for (int j = 1; j < values.Length; j++)
                {
                    //Check all Name field characters for apostrophes and escape them
                    if (j == 1)
                    {
                        int len = values[j].Length;
                        for (int k = 0; k < len; k++)
                        {
                            if (values[j][k] == '\'')
                            {
                                values[j] = values[j].Insert(k, "'");
                                //Skip the added aphostrophe
                                k++;
                            }
                        }
                    }

                    insertQuery += "'" + values[j] + "', ";
                }
                
                //Remove last two characters (range operator)
                insertQuery = insertQuery[..^2];
                //Same as insertQuery.Remove(insertQuery.Length - 2);

                insertQuery += ");";

                DB.QueryDB(insertQuery);
            }

            PlayerPrefs.SetString("FileHash", newHash);
        }

        //Delete old file
        File.Delete(oldFile);
        currentTask = "Done";
        loading = false;
    }

    void CreateTable(string tableName, string[] headers)
    {
        currentTask = "Creating table from data structure";
        //Drop any existing table of the same name
        string sql = "DROP TABLE IF EXISTS " + tableName;

        DB.QueryDB(sql);

        //Create table with info
        sql = "CREATE TABLE " + tableName +
            " (ID INTEGER PRIMARY KEY AUTOINCREMENT, ";

        for (int i = 1; i < headers.Length; i++)
            sql += headers[i] + " TEXT, ";

        //Remove ', ' after last entry
        sql = sql.Substring(0, sql.Length - 2);
        sql += ");";

        DB.QueryDB(sql);

        Debug.Log("Table " + tableName + " created");

    }
}
