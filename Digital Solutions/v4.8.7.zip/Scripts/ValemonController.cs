using UnityEngine;
using TMPro;
using DB = AsyncDBManager;
using System.Data;
using UnityEngine.SceneManagement;
using System.Collections;
using UnityEngine.UI;

public class ValemonController : MonoBehaviour
{
    Resolution screenRes;

    public GameObject SignupModal;

    public TMP_Text errorText;
    public TMP_Text errorDialogText;

    public InputController inputController;

    public GameObject pokemonRowPrefab;

    public DataManager dataManager;

    internal Pokemon[] pokemon;

    public RawImage img;

    public void Register()
    {
        //If no valid password, return
        if (!inputController.isPasswordValid)
        {
            errorText.text = "Password should contain 8 characters, a number, and a symbol";
            return;
        };
        //Apply regex to email
        if (!inputController.isEmailValid)
        {
            errorText.text = "Please enter a valid email";
            return;
        }
        //if no entered values in email or password, return
        if (inputController.emailInput.text == "" || inputController.passwordInput.text == "")
        {
            errorText.text = "Please enter an email and password";
            return;
        }

        //If user account email already exists, return
        IDataReader reader = DB.QueryDB($"SELECT * FROM users WHERE Email = '{inputController.emailInput.text}'");
        if (reader.Read())
        {
            errorText.text = "Email already exists. Login instead";
            return;
        }
        reader.Close();

        //Temp save password hash for comparison
        inputController.hashedPass = Extensions.HashPassword(inputController.passwordInput.text);

        //Unity based method (not secure)
        //inputController.hashedPass = Hash128.Compute(passwordInput.text).ToString();
        Debug.Log(inputController.hashedPass);

        inputController.emailConfInput.text = inputController.emailInput.text;

        //Clear inputs for modal
        inputController.passwordConfInput.text = "";
        inputController.nameInput.text = "";
        inputController.addressInput.text = "";

        //Open info modal to get finalise user details
        SignupModal.SetActive(true);
    }

    public void CompleteRegistration()
    {
        if (!inputController.AllowRegister())
        {
            errorDialogText.text = "Check your passwords match and you have filled all fields";
            return;
        }
        
        //Add user to DB
        DB.QueryDB($"INSERT INTO users (Email, HashedPassword, Name, Address) VALUES ('{inputController.emailInput.text}', '{inputController.hashedPass}', '{inputController.nameInput.text}', '{inputController.addressInput.text}')");

        SignupModal.SetActive(false);

        //Clear inputs
        inputController.emailInput.text = "";
        inputController.passwordInput.text = "";
        inputController.passwordConfInput.text = "";
        inputController.nameInput.text = "";
        inputController.addressInput.text = "";

        //clear temp saved hash
        inputController.hashedPass = "";
    }

    void Awake()
    {
        DB.InitiateConnection("valemon.db");
    }

    private void OnApplicationQuit()
    {
        DB.CloseConnection();
    }

    public void UpdateTexture(string id)
    {
        int i = int.Parse(id);
        img.texture = pokemon[i].texture;
    }

    // Start is called before the first frame update
    void Start()
    {
        errorText.text = "";
        screenRes = Screen.resolutions[Screen.resolutions.Length - 1];
        Screen.SetResolution((screenRes.height / 16) * 9, screenRes.height, true);
    }

    //This is called by the DataManager script when the DB has been validated and loaded, or when the user refreshes the main menu
    public IEnumerator LoadPokemon()
    {
        //Load all pokemon from the DB
        var reader = DB.QueryDB("SELECT COUNT(*) FROM pokemon");
        int count;
        if (reader.Read())
        {
            count = reader.SafeGet<int>(0);
        }
        else
        {
            Debug.LogError("DB not correctly loaded. Check your internet connection");
            yield break;
        }

        pokemon = new Pokemon[count];
        reader = DB.QueryDB("SELECT ID, name, classfication, type1, type2, abilities1, abilities2, abilities3, abilities4, abilities5, abilities6, generation, defense, attack, sp_attack, sp_defense, hp, height_m, weight_kg, speed FROM pokemon");
        int i = 0;
        while (reader.Read())
        {
            pokemon[i] = new Pokemon
            {
                //Get values from reader using SafeGet<T>
                id = reader.SafeGet<int>(0),
                name = reader.SafeGet<string>(1),
                type1 = reader.SafeGet<string>(3),
                type2 = reader.SafeGet<string>(4),
                abilities = new string[6] { reader.SafeGet<string>(5), reader.SafeGet<string>(6), reader.SafeGet<string>(7), reader.SafeGet<string>(8), reader.SafeGet<string>(9), reader.SafeGet<string>(10) },
                generation = int.Parse(reader.SafeGet<string>(11)),
                defense = int.Parse(reader.SafeGet<string>(12)),
                attack = int.Parse(reader.SafeGet<string>(13)),
                sp_attack = int.Parse(reader.SafeGet<string>(14)),
                sp_defense = int.Parse(reader.SafeGet<string>(15)),
                hp = int.Parse(reader.SafeGet<string>(16)),
                height = reader.SafeGet<string>(17),
                weight = reader.SafeGet<string>(18),
                speed = int.Parse(reader.SafeGet<string>(19))
            };

            //Get texture from web without blocking thread (i.e. project freezing while 648 images are loaded into memory)
            dataManager.StartCoroutine(dataManager.GetTexture(pokemon[i].id));
            Debug.Log("Pokemon " + (i + 1) + " loaded into memory");
            i++;
        }
        reader.Close();

        Debug.Log("All pokemon loaded into memory");
    }

    public void MainMenu()
    {
        SceneManager.LoadScene("Main");
    }
}
internal class Pokemon
{
    internal int id;
    internal string name;
    internal string type1;
    internal string type2;
    internal string[] abilities;
    internal int generation;
    internal int defense;
    internal int attack;
    internal int sp_attack;
    internal int sp_defense;
    internal int hp;
    internal string height;
    internal string weight;
    internal int speed;

    internal Texture texture;

    internal float StatTotal => defense + attack + sp_attack + sp_defense + hp + speed;
    internal float Cost => Mathf.Ceil((StatTotal / 16f) * 0.05f) / 0.05f;

}
