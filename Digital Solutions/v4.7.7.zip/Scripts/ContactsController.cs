using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;

public class ContactsController : MonoBehaviour
{
    Resolution screenRes;


    List<ContactPrefabManager> contactsList;
    
    GameObject contactPrefab;
    GameObject detailRowPrefab;

    public GameObject mainScrollContent;
    public GameObject detailsScrollContent;

    string query;

    public InputField searchField;

    public Canvas[] canvases;

    //View Contact Linking Elements

    public Text[] nameOccTexts;
    public Text[] birthdateTexts;
    public InputField notesInputField;
    public Text primaryDetailText;
    public Text addressText;

    //internal List<Detail> details;
    //internal List<Address> addresses;

    internal Dictionary<int, int> addressIDs;

    public Button editPrimaryDetailButton;

    //Detail Modal
    public GameObject detailModal;

    public Text titleText;
    public InputField valueInputField;
    public InputField tagInputField;
    public Toggle primaryToggle;
    public Dropdown tagDropDown;
    public Text redButtonText;

    int currContactID;
    int currDetailID;
    int currAddressID;
    int pDetailID;
    
    void Start()
    {
        //Set screen res
        screenRes = Screen.resolutions[Screen.resolutions.Length-1];
        Screen.SetResolution((screenRes.height / 16) * 9, screenRes.height, true);
        contactPrefab = Resources.Load<GameObject>("Prefabs/ContactRow");
        detailRowPrefab = Resources.Load<GameObject>("Prefabs/ContactDetailRow");

        LoadContactRows();
    }

    public void UpdateQuery()
    {
        query = searchField.text;
        query.Trim();
        if (string.IsNullOrWhiteSpace(query))
            query = "";
        
        LoadContactRows();
    }

    internal void DeleteContact(int id)
    {
        Debug.Log("Deleting contact with id: " + id);



        //DBManager.InitiateConnection("productivity.db");
        //Main Table
        //DBManager.QueryDB("DELETE FROM Contact WHERE ContactID = " + id);
        //Details Table
        //DBManager.QueryDB("DELETE FROM Details WHERE ContactID = " + id);
        //Address Table
        //DBManager.QueryDB("DELETE FROM Address WHERE ContactID = " + id);

        //DBManager.CloseConnection();


    }

    internal void LoadContact(int id)
    {
        
        Debug.Log("Loading contact with id: " + id);

        DBManager.InitiateConnection("productivity.db");

        currContactID = id;

        //Switch View
        canvases[0].gameObject.SetActive(false);
        canvases[1].gameObject.SetActive(true);

        //Change text fields
        DBManager.QueryDB("SELECT FirstName, Nickname, LastName, OtherName, DOB, Company, Department, JobTitle, Notes, PrimaryDetailID FROM Contact WHERE ContactID = " + id);
        while (DBManager.reader.Read())
        {
            nameOccTexts[0].text = DBManager.reader.SafeGet<string>(0) + " " + DBManager.reader.SafeGet<string>(2);
            nameOccTexts[1].text = ((DBManager.reader.SafeGet<string>(1) != "") ? ("'" + DBManager.reader.SafeGet<string>(1) + "'") : "") + ((DBManager.reader.SafeGet<string>(3) == "" || DBManager.reader.SafeGet<string>(1) == "") ? "" : " | ") + DBManager.reader.SafeGet<string>(3);
            Debug.Log(nameOccTexts[1].text);
            nameOccTexts[2].text = DBManager.reader.SafeGet<string>(7) + ((DBManager.reader.SafeGet<string>(6) == "") ? "" : " in ") + DBManager.reader.SafeGet<string>(6) + ((DBManager.reader.SafeGet<string>(7) == "") ? "" : " at ") + DBManager.reader.SafeGet<string>(5);
            System.DateTime dob = System.DateTime.ParseExact(DBManager.reader.SafeGet<string>(4), "dd/MM/yyyy", null);

            birthdateTexts[0].text = dob.ToString("d MMMM yyyy");
            //Total days divided by the statistical average # of days in the Gregorian Calendar Year, rounded (obv flawed method, will improve)
            birthdateTexts[1].text = (int)(System.DateTime.Now.Subtract(dob).Duration().TotalDays / 365.2425) + " years old";

            notesInputField.text = DBManager.reader.SafeGet<string>(8);

            pDetailID = DBManager.reader.SafeGet<int>(9);
        }

        DBManager.reader.Close();

        //Load and add contact details

        DBManager.QueryDB("SELECT Contact, DetailID, TypeTag FROM Details WHERE ContactID = " + id);

        bool hasPrimary = false;

        //details = new List<Detail>();

        foreach (Transform child in detailsScrollContent.transform)
            Destroy(child.gameObject);
        
        while (DBManager.reader.Read())
        {
            string t = DBManager.reader.SafeGet<string>(2) + (DBManager.reader.SafeGet<string>(2) == "" ? "" : ": ") + DBManager.reader.SafeGet<string>(0);

            //Set primary detail if it exists (if primary detail is deleted, the field will remain. The following logic should remain consistent despite this anomaly)
            if (DBManager.reader.SafeGet<int>(1) == pDetailID)
            {
                primaryDetailText.text = t;
                editPrimaryDetailButton.interactable = true;
                editPrimaryDetailButton.onClick.RemoveAllListeners();
                int did = DBManager.reader.SafeGet<int>(1);
                editPrimaryDetailButton.onClick.AddListener(() => { LoadDetailModal(did); });
                hasPrimary = true;
                continue;
            }
            //Build array and list
            //Show all contact at first, refine with filter options after
            GameObject contactDetailRow = Instantiate(detailRowPrefab, detailsScrollContent.transform);
            ContactDetailPrefabManager cdpm = contactDetailRow.GetComponent<ContactDetailPrefabManager>();
            cdpm.cc = this;
            cdpm.valueText.text = t;
            cdpm.detailID = DBManager.reader.SafeGet<int>(1);

            //details.Add(new Detail(DBManager.reader.SafeGet<string>(0), DBManager.reader.SafeGet<string>(2), DBManager.reader.SafeGet<int>(1)));
        }

        if (!hasPrimary)
        {
            primaryDetailText.text = "No primary contact set";
            editPrimaryDetailButton.interactable = false;
        }

        
        DBManager.reader.Close();

        addressIDs = new Dictionary<int, int>();

        //Parse contact addresses
        DBManager.QueryDB("SELECT AddressID FROM Address WHERE ContactID = " + id);
        
        int i = 0;
        while (DBManager.reader.Read())
        {
            //Add to dictionary
            addressIDs.Add(i, DBManager.reader.SafeGet<int>(0));
            i++;

            currAddressID = 0;
        }

        LoadAddress(currAddressID);

        DBManager.CloseConnection();
    }
    public void ChangeAddress(bool up)
    {
        if (up)
        {
            if (currAddressID + 1 < addressIDs.Count)
            {
                currAddressID++;
                LoadAddress(currAddressID);
            }            
        }
        else
        {
            if (currAddressID - 1 >= 0)
            {
                currAddressID--;
                LoadAddress(currAddressID);
            }
        }
    }    
    
    internal void LoadAddress(int id)
    {
        int addressID = addressIDs[id];
        currAddressID = id;
        Debug.Log("Loading address with DB id: " + addressID + " (local id: " + id + ")");
        //Load address
        DBManager.InitiateConnection("productivity.db");
        DBManager.QueryDB("SELECT Street1, Street2, Suburb, State, PostCode, Country, TypeTag FROM Address WHERE AddressID = " + addressID);
        if (DBManager.reader.Read())
        {
            Address a = new Address()
            {
                street1 = DBManager.reader.SafeGet<string>(0),
                street2 = DBManager.reader.SafeGet<string>(1),
                suburb = DBManager.reader.SafeGet<string>(2),
                state = DBManager.reader.SafeGet<string>(3),
                pcode = DBManager.reader.SafeGet<string>(4),
                country = DBManager.reader.SafeGet<string>(5),
                typeTag = DBManager.reader.SafeGet<string>(6)
            };

            addressText.text = a.value;
        }
        DBManager.CloseConnection();
    }

    //Link dropdown and text field
    public void ChangeDetailType(int index)
    {
        Debug.Log("Changed dropdown");
        if (index == 0)
            tagInputField.text = "";
        else
            tagInputField.text = tagDropDown.options[index].text;
    }
    //Set dropdown to default (custom) when text field is changed
    public void ChangeDetailTag(string tag)
    {
        Debug.Log("Changed text field");
        
        int i = tagDropDown.options.FindIndex(x => x.text == tag);
        
        if (i == -1)
            tagDropDown.value = 0;
        else tagDropDown.value = i;
    }

    public void LoadDetailModal(int id)
    {
        currDetailID = id;
        
        //Clear fields
        titleText.text = "Edit Detail";
        redButtonText.text = "Delete";
        primaryToggle.interactable = true;
        primaryToggle.isOn = id == pDetailID;
        valueInputField.text = "";
        tagInputField.text = "";
        tagDropDown.value = 0;

        //If id is 0, then create new detail
        if (id == 0)
        {
            Debug.Log("New detail, opening empty modal");

            primaryToggle.interactable = false;
            titleText.text = "Add Detail";
            redButtonText.text = "Cancel";
            detailModal.SetActive(true);
            return;
        }

        //Load detail data from database and fill fields
        Debug.Log("Loading detail modal with id: " + id);

        DBManager.InitiateConnection("productivity.db");
        DBManager.QueryDB("SELECT Contact, TypeTag FROM Details WHERE DetailID = " + id);
        if (DBManager.reader.Read())
        {
            valueInputField.text = DBManager.reader.SafeGet<string>(0);

            int i = tagDropDown.options.FindIndex(x => x.text == tagInputField.text);

            if (i == -1)
                tagDropDown.value = 0;
            else tagDropDown.value = i;
            tagInputField.text = DBManager.reader.SafeGet<string>(1);
        }



        DBManager.CloseConnection();

        detailModal.SetActive(true);
    }
    public void SaveDetailInfo()
    {
        DBManager.InitiateConnection("productivity.db");
        //If value is empty, return
        if (valueInputField.text == "")
        {
            Debug.Log("Value is empty");
            return;
        }

        //If id is 0, then create new detail
        if (currDetailID == 0)
            DBManager.QueryDB("INSERT INTO Details (Contact, TypeTag, ContactID) VALUES ('" + valueInputField.text + "', '" + tagInputField.text + "', '" + currContactID + "')");
        else
            DBManager.QueryDB("UPDATE Details SET Contact = '" + valueInputField.text + "', TypeTag = '" + tagInputField.text + "' WHERE DetailID = " + currDetailID);
        
        if (primaryToggle.isOn)
            DBManager.QueryDB("UPDATE Contact SET PrimaryDetailID = " + currDetailID + " WHERE ContactID = " + currContactID);
        else if (currDetailID == pDetailID)
            DBManager.QueryDB("UPDATE Contact SET PrimaryDetailID = NULL WHERE ContactID = " + currContactID);

        DBManager.CloseConnection();
        
        //Reload contact details
        LoadContact(currContactID);
    }
    public void DeleteDetailInfo()
    {
        //If new return (cancel)
        if (currDetailID == 0)
            return;
        Debug.Log("Deleting detail with id: " + currDetailID);
        //Delete from database
        DBManager.InitiateConnection("productivity.db");
        DBManager.QueryDB("DELETE FROM Details WHERE DetailID = " + currDetailID);
        DBManager.CloseConnection();

        //Reload contact details
        LoadContact(currContactID);
    }

    void LoadContactRows()
    {
        //Remove any existing children
        foreach (Transform child in mainScrollContent.transform)
            Destroy(child.gameObject);
        
        //Query DB
        DBManager.InitiateConnection("productivity.db");

        string q = $"SELECT FirstName, LastName, Nickname, ContactID FROM Contact WHERE " +
            $"FirstName LIKE \"%{query}%\" OR " +
            $"Nickname LIKE \"%{query}%\" OR " +
            $"LastName LIKE \"%{query}%\" OR " +
            $"OtherName LIKE \"%{query}%\" OR " +
            $"ContactID LIKE \"{query}\"";
        
        DBManager.QueryDB(q);

        contactsList = new List<ContactPrefabManager>();
        
        //Make prefab and assign values
        while (DBManager.reader.Read())
        {
            GameObject contactRow = Instantiate(contactPrefab, mainScrollContent.transform);
            ContactPrefabManager cpm = contactRow.GetComponent<ContactPrefabManager>();
            cpm.PopulateFields(DBManager.reader.SafeGet<string>(0), DBManager.reader.SafeGet<string>(2), DBManager.reader.SafeGet<string>(1), DBManager.reader.SafeGet<int>(3), this);
            contactsList.Add(cpm);
        }

        DBManager.CloseConnection();
    }
    void Update()
    {
        //Profiling shows this reduces redundant calls inherent in GetKeyDown method.
        if (Input.anyKeyDown)
        {
            //UX Feature - Quick delete entire search string
            if (Input.GetKeyDown(KeyCode.Delete) && EventSystem.current.currentSelectedGameObject == searchField.gameObject)
            {
                searchField.text = "";
                UpdateQuery();
            }
        }
    }

    private void OnApplicationQuit()
    {
        //Reset Screen Resolution
        Screen.SetResolution(screenRes.width, screenRes.height, true);
    }
    public void MainMenu()
    {
        SceneManager.LoadScene("Main");
        
    }
}


[System.Serializable]
struct Address
{
    /// <summary>
    /// Preformatted address value, assuming Australian locale.
    /// </summary>
    public string value => string.Join("\n", string.Join(" ", street1, street2), string.Join(" ", suburb, pcode), string.Join(" ", state, country)).Trim();
    
    //Data
    internal string street1;
    internal string street2;
    internal string suburb;
    internal string state;
    internal string pcode;
    internal string country;

    internal string typeTag;
    internal int id;
}
[System.Serializable]
struct Detail
{
    internal string value { get; }
    internal string typeTag { get; }
    internal int id { get; }

    //Ensures struct is immutable
    public Detail(string _value, string _typeTag, int _id) : this()
    {
        value = _value;
        typeTag = _typeTag;
        id = _id;
    }
}

