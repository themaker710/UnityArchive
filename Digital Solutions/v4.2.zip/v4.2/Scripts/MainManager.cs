using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainManager : MonoBehaviour
{
    public RectTransform ParentPanel;
    public Text version, pageText;
    public InputField sceneTestCount;
    public Button toggleButton;
    public Dropdown catDropdown;
    GameObject buttonPrefab;
    GameObject[] pageChangers;


    string[] sceneNames = { }, assessmentNames = { }, projectNames = { }, hiddenNames = { }, scenePaths = { };

    string[] dbNames = { "words.db", "vending.db" };
    int page = 0, maxpages = 1, sceneCount, cat = 0;
    bool testingPages = false;

    void Start()
    {
#if UNITY_STANDALONE_WIN && !UNITY_EDITOR
        CheckDB();
        Debug.Log("Production");
#endif
#if UNITY_EDITOR
        Debug.Log("Editor");
#endif
        version.text = "Version: " + Application.version;
        buttonPrefab = Resources.Load<GameObject>("Prefabs/SceneMenuButton");
        pageChangers = GameObject.FindGameObjectsWithTag("pageControl");
        sceneCount = SceneManager.sceneCountInBuildSettings;

        List<string> hiddenTemp = new List<string>();
        List<string> allTemp = new List<string>();
        List<string> scenePathTemp = new List<string>();

        for (int i = 0; i < sceneCount; i++)
        {
            string path = SceneUtility.GetScenePathByBuildIndex(i);
            string name = Path.GetFileNameWithoutExtension(path);

            if (path.Contains("Hidden"))
            {
                hiddenTemp.Add(name);
                //Debug.Log("Hidden: \n" + name);
            }
            else if (!path.Contains("Main"))
            {
                allTemp.Add(name);
                scenePathTemp.Add(path);
                //Debug.Log($"Valid scene: {name}");
            }

        }
        hiddenTemp.Sort();
        scenePathTemp.Sort();
        allTemp.Sort();
        hiddenNames = hiddenTemp.ToArray();
        scenePaths = scenePathTemp.ToArray();
        sceneNames = allTemp.ToArray();

        sceneCount = sceneNames.Length;
        Debug.Log($"Hidden Scenes: {hiddenNames.Length}");
        Debug.Log($"All Scenes: {sceneCount}");

        List<string> assessementTemp = new List<string>();
        List<string> projectTemp = new List<string>();

        foreach (string path in scenePaths)
        {
            string name = Path.GetFileNameWithoutExtension(path);

            if (path.Contains("Assessment") && !path.Contains("Hidden"))
            {
                assessementTemp.Add(name);
                //Debug.Log("Assessment: " + name);
            }


            if (path.Contains("Projects") && !path.Contains("Hidden"))
            {
                projectTemp.Add(name);
                //Debug.Log("Project: \n" + name);
            }

        }
        assessementTemp.Sort();
        projectTemp.Sort();
        assessmentNames = assessementTemp.ToArray();
        projectNames = projectTemp.ToArray();

        Debug.Log($"Assessment Scenes: {assessmentNames.Length}");
        Debug.Log($"Project Scenes: {projectNames.Length}");
        Initialize();
    }

    void Initialize()
    {

        if (testingPages)
        {
            sceneCount = (sceneTestCount.text == "") ? 34 : int.Parse(sceneTestCount.text) + 1;
            sceneNames = new string[sceneCount];
            Debug.Log("Testing pages");
            catDropdown.enabled = false;
            for (int i = 0; i < sceneCount; i++)
            {
                sceneNames[i] = i.ToString();
            }
        }
        else
        {
            catDropdown.enabled = true;
            sceneCount = (cat == 1) ? assessmentNames.Length : (cat == 2) ? projectNames.Length : sceneNames.Length;
            Debug.Log($"Scene Count: {sceneCount}");
        }

        Debug.Log(sceneCount + " scenes found");

        Buttons();

        ConstructPage(page);
    }
    void Buttons()
    {

        maxpages = (int)Mathf.Ceil(sceneCount / 12);

        //deal with buttons
        if (sceneCount > 12)
        {
            foreach (GameObject go in pageChangers)
            {
                go.SetActive(true);
            }

        }
        else
        {
            foreach (GameObject go in pageChangers)
            {
                go.SetActive(false);

            }
        }

        //Plus 1 to be 1 based instead of 0 based - More user friendly
        pageText.text = (page + 1) + "/" + (maxpages + 1);
    }
    void ConstructPage(int pagenum)
    {
        // delete the existing buttons if any
        foreach (Transform child in ParentPanel.transform)
        {
            Destroy(child.gameObject);
        }


        int xpos = -625, i = (pagenum * 12);
        //Number of buttons on the page: 12 or total - already shown buttons.
        int limit = (pagenum == maxpages) ? sceneCount - (pagenum * 12) : 12;
        Debug.Log($"Page Limit: {limit}");

        for (int position = 0; position < limit; position++)
        {
            string curScene = (cat == 1) ? assessmentNames[i] : (cat == 2) ? projectNames[i] : sceneNames[i];

            //Skipping Conditions
            if (curScene == "Main") i++;
            if (hiddenNames.Contains(curScene)) i++;
            if (cat == 1 && !assessmentNames.Contains(curScene)) i++;
            if (cat == 2 && !projectNames.Contains(curScene)) i++;

            //Debug.Log("Position: " + position + "\nScene Index: " + i);

            //Instantiate button
            GameObject goButton = Instantiate(buttonPrefab);
            //Organise instatiated buttons to be easily deleted
            goButton.transform.SetParent(ParentPanel, false);
            //Fix default scale
            goButton.transform.localScale = new Vector3(1, 1, 1);
            //Set x position and row
            goButton.transform.localPosition = new Vector3(xpos, position <= 5 ? 150 : -150, 0);
            //Get object as a button object instead of GO for button specific tasks.

            string curName = "";

            //Add user readability i.e. spaces between words
            foreach (char c in curScene)
            {
                if (char.IsUpper(c))
                {
                    curName += ' ';
                    curName += c;
                }
                else
                {
                    curName += c;
                }
            }
            curName.Trim();

            //Dynamic Components - Button text and OnClick event
            Button tempButton = goButton.GetComponent<Button>();
            tempButton.GetComponentInChildren<Text>().text = curName;
            tempButton.onClick.AddListener(() => ButtonClicked(curScene));

            //New row if top row is full
            xpos = position == 5 ? -625 : xpos += 250;

            i++;
        }
        Debug.Log($"Page {pagenum + 1} Buttons Loaded");
    }

    void CheckDB()
    {
        for (int i = 0; i < dbNames.Length; i++)
        {
            string clientPath = Path.Combine(Application.persistentDataPath, dbNames[i]);
            if (!File.Exists(clientPath))
            {
                byte[] data;

                try
                {
                    data = File.ReadAllBytes(Path.Combine(Application.streamingAssetsPath, dbNames[i]));
                }
                catch (FileNotFoundException)
                {
                    Debug.Log($"Please add the {dbNames[i]} file to StreamingAssets before copying operations can take place");
                    break;
                }

                File.WriteAllBytes(clientPath, data);
                Debug.Log("DB copied");
            }
        }
    }

    void ButtonClicked(string scene)
    {
        Debug.Log("Scene " + scene + " loading...");

        if (!testingPages) SceneManager.LoadScene(scene);
        else Debug.Log(scene + " Testing");


        Debug.Log("Loaded!");

    }
    public void ChangePage(bool up)
    {
        //Next page is clicked and not at the last page turn the page
        if (up && !(page == maxpages)) page++;
        //Back page click and not at first page then turn page
        else if (!up && !(page == 0)) page--;
        else return;
        pageText.text = (page + 1) + "/" + (maxpages + 1);
        ConstructPage(page);
    }
    public void ToggleTesting()
    {
        testingPages = (testingPages) ? false : true;
        toggleButton.GetComponentInChildren<Text>().text = "Test Page System: " + testingPages.ToString().ToUpper();
        string type = (testingPages) ? " DEBUG" : " PROD";
        version.text = "Version: " + Application.version + type;

        catDropdown.value = 0;
        cat = catDropdown.value;
        page = 0;

        //foreach (Transform child in ParentPanel.transform)
        //{
        //    Destroy(child.gameObject);
        //}

        if (testingPages) Initialize();
        else Start();
    }
    public void ChangeCat()
    {
        //0 = All, 1 = Assessments, 2 = Projects
        cat = catDropdown.value;
        page = 0;
        Debug.Log($"Category: {cat}");

        Initialize();
    }
    public void StopApplication()
    {
        Application.Quit();
    }
}
