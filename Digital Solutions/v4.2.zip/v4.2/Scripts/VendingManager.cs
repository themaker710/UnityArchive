using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class VendingManager : MonoBehaviour
{

    //Unity Linking Variables
    public Text outputText;
    public RectTransform selectionPanel;

    //General variable definitions
    bool fundsAdded;
    string output = "";

    // Product data array defintions
    string[] productNames;
    int[] productQuantities;
    decimal[] productPrice;

    void Start()
    {
        StartVending();
    }

    //Reset vending machine
    void StartVending()
    {
        //Update product information
        UpdateText();
        //Reset variables
        fundsAdded = false;
        output = "";
    }
    public void UpdateText()
    {
        //Create variables with appropriate length (however many option panels there are)
        productNames = new string[selectionPanel.childCount];
        productQuantities = new int[selectionPanel.childCount];
        productPrice = new decimal[selectionPanel.childCount];

        //Start db connection
        DBManager.InitiateConnection("/vending.db");

        //Loop through all selection options
        for (int i = 0; i < selectionPanel.childCount; i++)
        {
            //Query DB for database row of id
            DBManager.QueryDB("SELECT * FROM Products WHERE ID = " + (i + 1));

            //Declare intermediatary variables
            decimal price = 0;
            int quantity = 0;
            string name = "";

            //Read info from DB reader datastream
            while(DBManager.reader.Read())
            {
                name = DBManager.reader.GetString(1);
                quantity = DBManager.reader.GetInt16(2);
                price = DBManager.reader.GetDecimal(3);
            }

            //Get the option panel to be edited
            Transform optionPanel = selectionPanel.transform.GetChild(i).transform;

            //Input values into array for use at the end
            productNames[i] = name;
            productQuantities[i] = quantity;
            productPrice[i] = price;
            
            //Set the name text element with the database retrieved info
            optionPanel.GetChild(0).GetComponent<Text>().text = name;

            //Set the price text element with database retrieved info. This is then formatted using 'Standard Numeric Format Strings' seen in the ToString method
            //F2 means a Fixed point, with 2 representing the number of values past the decimal point.
            optionPanel.GetChild(2).GetComponent<Text>().text = "$" + price.ToString("F2");

            //Set the quantity text element with database retrieved info.
            //Similar to above, with D = Decimal and the 2 specifying the set number of digits
            optionPanel.GetChild(3).GetComponent<Text>().text = quantity.ToString("D2");

            //Cleanup 
            DBManager.reader.Close();

        }
        //Cleanup
        DBManager.CloseConnection();
    }
    void ItemBought(int index)
    {
        //Update database by taking one away from quantity variable
        DBManager.InitiateConnection("/vending.db");
        DBManager.QueryDB($"UPDATE Products SET CurrentQuantity = CurrentQuantity - 1 WHERE ID = {index}");
        DBManager.CloseConnection();
    }
    public void RestockAll()
    {
        //Update database by setting all quantities to 10
        DBManager.InitiateConnection("/vending.db");
        DBManager.QueryDB($"UPDATE Products SET CurrentQuantity = 10");
        DBManager.CloseConnection();
        UpdateText();
    }
    public void KeyPadPress(string input)
    {
        //User must add funds first (click button)
        if (!fundsAdded)
        {
            outputText.text = "Please add funds to begin transaction";
            return;
        }
        //If input cleared - Should this reset the funds bool as well??
        if (input == "*")
        {
            output = "";
            outputText.text = output;
            return;
        }
        //If input is submit
        if (input == "#")
        {
            //Parse the input to be tested - tryparse will simply skip if it fails.
            int.TryParse(output, out int id);
            //If input is empty
            if (output == "")
            {
                outputText.text = "Please input a drink position";
                return;
            }
            //If selected number is an option
            else if (id <= 9 && id > 0)
            {
                //Array index: 0 based
                int i = id - 1;

                //If there is none of the drink left
                if (productQuantities[i] == 0)
                {
                    outputText.text = $"No {productNames[i]} stock\nChoose another again";
                    output = "";
                    return;
                }

                //Give user feedback that product was purchased
                outputText.text = $"{productNames[i]} Dispensed for {"$" + productPrice[i].ToString("F2")}. Please collect below";
                //Update DB
                ItemBought(id);
                //Reset interface
                StartVending();
                return;
            }
            //If input is invalid or unknown i.e. not caught by any other conditions above
            else
            {
                outputText.text = "Please enter a valid code e.g. 01, 1, 02, 2, etc";
                output = "";
                return;
            }
        }

        //Append inputted value to the output
        output += input;
        //Update UI element
        outputText.text = output;
    }
    public void AddFunds()
    {
        //Button to add funds
        fundsAdded = true;
        output = "";
        outputText.text = "Select a drink by the bottom right corner number";
    }
    private void Update()
    {
        //Keypad Listener
        if (Input.GetKeyDown(KeyCode.KeypadMultiply) ||
            ((Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift)) && Input.GetKeyDown(KeyCode.Alpha8)))
        {
            KeyPadPress("*");
        }
        else if (Input.GetKeyDown(KeyCode.Keypad8) || Input.GetKeyDown(KeyCode.Alpha8))
        {
            KeyPadPress("8");
        }
        if ((Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift)) && Input.GetKeyDown(KeyCode.Alpha3))
        {
            KeyPadPress("#");
        }
        else if (Input.GetKeyDown(KeyCode.Keypad3) || Input.GetKeyDown(KeyCode.Alpha3))
        {
            KeyPadPress("3");
        }
        if (Input.GetKeyDown(KeyCode.Keypad0) || Input.GetKeyDown(KeyCode.Alpha0))
        {
            KeyPadPress("0");
        }
        if(Input.GetKeyDown(KeyCode.Keypad1) || Input.GetKeyDown(KeyCode.Alpha1))
        {
            KeyPadPress("1");
        }
        if (Input.GetKeyDown(KeyCode.Keypad2) || Input.GetKeyDown(KeyCode.Alpha2))
        {
            KeyPadPress("2");
        }
        if (Input.GetKeyDown(KeyCode.Keypad4) || Input.GetKeyDown(KeyCode.Alpha4))
        {
            KeyPadPress("4");
        }
        if (Input.GetKeyDown(KeyCode.Keypad5) || Input.GetKeyDown(KeyCode.Alpha5))
        {
            KeyPadPress("5");
        }
        if (Input.GetKeyDown(KeyCode.Keypad6) || Input.GetKeyDown(KeyCode.Alpha6))
        {
            KeyPadPress("6");
        }
        if (Input.GetKeyDown(KeyCode.Keypad7) || Input.GetKeyDown(KeyCode.Alpha7))
        {
            KeyPadPress("7");
        }
        if (Input.GetKeyDown(KeyCode.Keypad9) || Input.GetKeyDown(KeyCode.Alpha9))
        {
            KeyPadPress("9");
        }
        if (Input.GetKeyDown(KeyCode.Backspace))
        {
            if (output == "") return;
            output = output.Remove(output.Length - 1);
            outputText.text = output;
        }
        if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter))
        {
            KeyPadPress("#");
        }

    }
    public void MainMenu()
    {
        SceneManager.LoadScene("Main");
    }
}
