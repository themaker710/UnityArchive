using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ContactPrefabManager : MonoBehaviour
{
    public Button removeButton;
    
    public Text nameText;

    internal Contact contact;

    internal void PopulateFields(Contact c)
    {
        contact = c;
        nameText.text = contact.name;
    }
    
    public void OpenPage()
    {
        throw new System.NotImplementedException();    
    }

    public void DeleteEntry()
    {
        throw new System.NotImplementedException();    
    }
}
