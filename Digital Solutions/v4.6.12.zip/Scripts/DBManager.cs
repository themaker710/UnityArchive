using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mono.Data.Sqlite;
using System.Data;
/// <summary>
/// Database helper utility.
/// </summary>
public class DBManager
{
    /// <summary>
    /// Database reader object
    /// </summary>
    public static IDataReader reader;
    private static IDbConnection dbcon; 

    /// <summary>
    /// Initiate a SQLite connection with the specified database filepath.
    /// </summary>
    /// <param name="dbPath">Path to database .db file</param>
    public static void InitiateConnection(string dbPath)
    {
        string connection = "URI=file:" + Application.persistentDataPath + dbPath;
        dbcon = new SqliteConnection(connection);
        dbcon.Open();

        Debug.Log($"DB file at {connection} was successfully opened");
    }
    /// <summary>
    /// A query handler that sets the reader object.
    /// </summary>
    /// <param name="query">SQL Query</param>
    public static void QueryDB(string query)
    {
        IDbCommand dbcmd;
        //if (dbcon == null) throw new NoNullAllowedException();
        dbcmd = dbcon.CreateCommand();

        dbcmd.CommandText = query;
        reader = dbcmd.ExecuteReader();
        dbcmd.Dispose();
        dbcmd = null;

    }
    /// <summary>
    /// Close any open database connections
    /// </summary>
    public static void CloseConnection()
    {
        reader.Close(); // clean everything up
        reader = null;
        dbcon.Close();
        dbcon = null;
    }
}