using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using DB = AsyncDBManager;
using System.Drawing.Text;
using System.Data;
using UnityEngine.Scripting;
using Mono.Data.Sqlite;
using UnityEngine.SceneManagement;

public class ValemonController : MonoBehaviour
{
    Resolution screenRes;

    public TMP_InputField emailInput;
    public TMP_InputField passwordInput;

    public TMP_InputField emailConfInput;
    public TMP_InputField passwordConfInput;
    public TMP_InputField nameInput;
    public TMP_InputField addressInput;

    public GameObject SignupModal;

    public TMP_Text errorText;
    public TMP_Text errorDialogText;

    public InputController inputController;

    public void Register()
    {
        //If no valid password, return
        if (!inputController.isPasswordValid)
        {
            errorText.text = "Password should contain 8 characters, a number, and a symbol";
            return;
        };
        //Apply regex to email
        if (!inputController.isEmailValid)
        {
            errorText.text = "Please enter a valid email";
            return;
        }
        //if no entered values in email or password, return
        if (emailInput.text == "" || passwordInput.text == "")
        {
            errorText.text = "Please enter an email and password";
            return;
        }

        //If user account email already exists, return
        IDataReader reader = DB.QueryDB($"SELECT * FROM users WHERE Email = '{emailInput.text}'");
        if (reader.Read())
        {
            errorText.text = "Email already exists. Login instead";
            return;
        }
        reader.Close();
        Debug.Log("test");
        //Temp save password hash for comparison
        inputController.hashedPass = Extensions.HashPassword(passwordInput.text);

        //Unity based method (not secure)
        //inputController.hashedPass = Hash128.Compute(passwordInput.text).ToString();
        Debug.Log(inputController.hashedPass);

        emailConfInput.text = emailInput.text;

        //Clear inputs for modal
        passwordConfInput.text = "";
        nameInput.text = "";
        addressInput.text = "";

        //Open info modal to get finalise user details
        SignupModal.SetActive(true);
    }

    public void CompleteRegistration()
    {
        if (!inputController.AllowRegister())
        {
            errorDialogText.text = "Check your passwords match and you have filled all fields";
            return;
        }
        
        //Add user to DB
        IDataReader reader = DB.QueryDB($"INSERT INTO users (Email, HashedPassword, Name, Address) VALUES ('{emailInput.text}', '{inputController.hashedPass}', '{nameInput.text}', '{addressInput.text}')");
        reader.Read();
        reader.Close();

        SignupModal.SetActive(false);

        //Clear inputs
        emailInput.text = "";
        passwordInput.text = "";
        passwordConfInput.text = "";
        nameInput.text = "";
        addressInput.text = "";

        //clear temp saved hash
        inputController.hashedPass = "";
    }

    void Awake()
    {
        DB.InitiateConnection("valemon.db");
    }

    private void OnApplicationQuit()
    {
        DB.CloseConnection();
    }

    // Start is called before the first frame update
    void Start()
    {
        errorText.text = "";
        screenRes = Screen.resolutions[Screen.resolutions.Length - 1];
        Screen.SetResolution((screenRes.height / 16) * 9, screenRes.height, true);
    }

    public void MainMenu()
    {
        SceneManager.LoadScene("Main");
    }
}
