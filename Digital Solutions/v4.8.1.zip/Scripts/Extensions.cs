using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using UnityEngine;

//Internal allows namespace script access
internal static class Extensions
{
    /// <summary>
    /// Generic SafeGet retrieves variables from the database, however inserts the default value in case of a null field.
    /// </summary>
    /// <typeparam name="T">Type of variable retrieving.</typeparam>
    /// <param name="index">Position of variable in query</param>
    /// <returns>Generic return variable</returns>
    internal static T SafeGet<T>(this IDataReader reader, int index)
    {
        //Shorthand version
        //if (!reader.IsDBNull(index))
        //    return (T)reader.GetValue(index);
        //return default;

        //This version handles potential known errors and increases usability.
        //According to some profiling reports, this way to check for null can cause major lag spikes and latency in other connections/queries. Optimization recommended.
        if (!reader.IsDBNull(index))
        {
            object value = reader.GetValue(index);
            System.Type type = value.GetType();
            
            //NUMBER datatype stored as 'long' datatype in SQLite (i.e. Int64)
            if (type == typeof(long))
            {
                //Unpack as int and update type. Implicit cast possible as int < long data wise.
                value = (int)(long)value;
                type = typeof(int);
            }

            if (type != typeof(T))
            {
                Debug.Log($"Expected data type '{typeof(T)}' was not returned, got '{type}' instead.");
                throw new System.FormatException("Type does not match retrieved data. Check specified type and try again");
            }
            else
                return (T)value;
        }
        Debug.Log($"Specified row of field '{reader.GetName(index)}' null, returning default value for {typeof(T)}");
        return default;
    }
    //Iterate through a dictionaries values and return the key
    internal static TKey GetKey<TKey, TValue>(this Dictionary<TKey, TValue> dict, TValue value)
    {
        foreach (KeyValuePair<TKey, TValue> pair in dict)
        {
            if (pair.Value.Equals(value))
                return pair.Key;
        }
        return default;
    }
    internal static bool IsNullOrWhiteSpace(this string str)
    {
        return string.IsNullOrWhiteSpace(str);
    }
    internal static int IndexOf(this System.Array arr, object query)
    {
        return System.Array.IndexOf(arr, query);
    }
    internal static bool IsLetter(this char c)
    {
        return char.IsLetter(c);
    }
    //internal static string Join(this System.Array arr, string seperator)
    //{
    //    return string.Join(seperator, arr);
    //}
    internal static char ToUpper(this char c)
    {
        return char.ToUpper(c);
    }
}
