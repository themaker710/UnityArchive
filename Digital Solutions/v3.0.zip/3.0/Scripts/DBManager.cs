using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mono.Data.Sqlite;
using System.Data;
/// <summary>
/// Database helper utility.
/// </summary>
public class DBManager
{
    /// <summary>
    /// Initiate a SQLite connection with the specified database filepath.
    /// </summary>
    /// <param name="dbPath">Path to database .db file</param>
    public static IDbConnection InitiateConnection(string dbPath)
    {
        IDbConnection dbcon;
        string connection = "URI=file:" + Application.persistentDataPath + dbPath;
        Debug.Log(connection);
        dbcon = new SqliteConnection(connection);

        dbcon.Open();
        return dbcon;
    }
    /// <summary>
    /// A  query handler that passes the reader object.
    /// </summary>
    /// <param name="query">SQL Query</param>
    /// <returns>Reader</returns>
    public static IDataReader QueryDB(string query, IDbConnection dbcon)
    {
        IDbCommand dbcmd;
        IDataReader reader;
        //if (dbcon == null) throw new NoNullAllowedException();
        dbcmd = dbcon.CreateCommand();

        dbcmd.CommandText = query;
        reader = dbcmd.ExecuteReader();
        dbcmd.Dispose();
        dbcmd = null;
        return reader;

    }
    /// <summary>
    /// Close any open database connections
    /// </summary>
    public static void CloseConnection(IDbConnection dbcon = null, IDataReader reader = null)
    {
        reader.Close(); // clean everything up
        reader = null;
        dbcon.Close();
        dbcon = null;
    }
}