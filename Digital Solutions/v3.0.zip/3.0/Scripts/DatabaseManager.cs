using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mono.Data.Sqlite;
using System.Data;
using System.IO;

public class DatabaseManager : MonoBehaviour
{
    IDbConnection dbcon;
    // Start is called before the first frame update
    void Start()
    {
        string connection = "URI=file:Assets/StreamingAssests/words.db";
        dbcon = new SqliteConnection(connection);
        dbcon.Open();
        
        IDbCommand dbcmd;
        IDataReader reader;

        dbcmd = dbcon.CreateCommand();
        string testQuery =
          //"SELECT Word, Length, Uses, Solves FROM \"Random Words\" WHERE Length = 4";
          "SELECT Length, count(*) as 'Count' FROM \"Random Words\" GROUP BY Length";

        dbcmd.CommandText = testQuery;
        reader = dbcmd.ExecuteReader();
        while (reader.Read())
        {
            Debug.Log(reader.GetInt32(0) + ": " + reader.GetInt32(1));
        }

        reader.Close();
    }

    // Update is called once per frame
    void Update()
    {

    }
}
