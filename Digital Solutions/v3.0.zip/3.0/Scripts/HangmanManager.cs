using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Data;
using System.Collections.Generic;
 
public class HangmanManager : MonoBehaviour
{
    public Text numWordsText;
    public Dropdown difficultyDropdown;

    internal static int difficulty = 0;
    internal static int[] numWords;




    void Start()
    {
        GetNumWords();
        DifficultyChange();
    }
    public void DifficultyChange()
    {
        // 0 = All, 1 = Easy, 2 = Medium, 3 = Hard, 4 = Very Hard
        difficulty = difficultyDropdown.value;
        Debug.Log(difficulty);
        numWordsText.text = numWords[difficulty].ToString() + " words";
    }
    public void PlayGame()
    {
        SceneManager.LoadScene("HangmanGame");
    }
    public void MainMenu()
    {
        //Main menu button functionality
        SceneManager.LoadScene("Main");
    }
    void GetNumWords()
    {
        Debug.Log("Getting number of words");
        IDbConnection dbcon = DBManager.InitiateConnection("/words.db");
        List<int> wordsList = new List<int>();
        string sqlQuery =
          "SELECT Length, count(*) as 'Count' FROM \"Random Words\" GROUP BY Length\n" +
          "UNION\n" +
          "SELECT 0, count(*) as 'Count' FROM \"Random Words\"";

        IDataReader reader = DBManager.QueryDB(sqlQuery, dbcon);
        while (reader.Read()) { wordsList.Add(reader.GetInt32(1)); };

        DBManager.CloseConnection(dbcon, reader);

        numWords = wordsList.ToArray();
    }

}


