using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Audio;
using UnityEngine.SceneManagement;
using System.Linq;

public class BlackjackController : MonoBehaviour
{
    //Unity linking variables
    public GameObject optionsPanel;
    public GameObject pregameInput;
    public GameObject gameElements;
    public GameObject gameInput;
    public GameObject cardPrefab;
    public GameObject drawPile;
    public Text volumeText;
    public Text betText;
    public Text cashText;
    public Text dealerText;
    public Text playerText;



    //Canvases
    public Canvas menuCanvas;
    public Canvas playCanvas;

    //Options interactables
    public Slider volSlider;
    public Toggle bettingToggle;
    public Toggle handValueToggle;

    //Game elements
    public Image[] chipImages;

    //Audio components
    public AudioSource cardAudio;
    public AudioMixer audioMixer;
    public AudioClip cardAudioClip;


    //General variables
    float vol = 1;

    bool bettingEnabled = true, showHandValue = true;

    //Card values
    string[] cardSuits = { "c", "d", "h", "s" };
    string[] cardValues = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };


    public Hand cardsInOrder;
    public Hand cardsInPlay;

    public Hand playerHand;
    public Hand dealerHand;

    int cash = 1000, bet = 0;

    Vector3 playerHandPos = new Vector3(-145, -210, 0);
    Vector3 dealerHandPos = new Vector3(125, 110, 0);
    Quaternion playerHandRot = new Quaternion(0, 0, -180, 0);
    Quaternion dealerHandRot = new Quaternion(0, 0, 180, 0);

    bool moving = false;

    //<1000 - 5, 10, 20, 50, 100, 250
    //>1000 - 25, 50, 100, 250, 500, 1000
    //>2000 - 50, 100, 250, 500, 1000, 2000
    //>5000 - 100, 250, 500, 1000, 2000, 5000
    int[][] bettingOptions = { new int[] { 5, 10, 20, 50, 100, 250 }, new int[] { 25, 50, 100, 250, 500, 1000 }, new int[] { 50, 100, 250, 500, 1000, 2000 }, new int[] { 100, 250, 500, 1000, 2000, 5000 } };
    int howRich = 0;

    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("main script started");

        //Set option values from storage if present

        bettingEnabled = PlayerPrefs.GetInt("bettingEnabled") == 1 ? true : false;
        bettingToggle.isOn = bettingEnabled;

        showHandValue = PlayerPrefs.GetInt("showHandValue") == 1 ? true : false;
        handValueToggle.isOn = showHandValue;

        vol = PlayerPrefs.GetFloat("volume");
        volSlider.value = vol;
        ChangeVolume(vol);

        // Set cash amount
        if (PlayerPrefs.HasKey("cash"))
            cash = PlayerPrefs.GetInt("cash");




        //Initialize card arrays

        cardsInOrder.cards = new List<Card>();
        cardsInPlay.cards = new List<Card>();

        


        //For each suit
        foreach (string suit in cardSuits)
        {
            //And each card value
            foreach (string denomination in cardValues)
            {
                //Add to the deck
                Card c = new Card();

                c.suit = suit;
                c.denomination = denomination;
                

                cardsInOrder.AddCard(c);
            }
        }
    }

    public void InitializeGame()
    {
        //Start game
        Debug.Log("play button pressed");
        playCanvas.gameObject.SetActive(true);
        menuCanvas.gameObject.SetActive(false);

        //Open appropriate controls
        pregameInput.SetActive(true);
        gameInput.SetActive(false);
        gameElements.SetActive(false);

        //Remove existing cards
        //foreach (GameObject go in cards)
        //{
        //    Debug.Log("Deleting " + go.name);
        //    Destroy(gameObject);
        //}

        foreach (Card c in playerHand.cards)
        {
            Destroy(c.go);
        }
        foreach (Card c in dealerHand.cards)
        {
            Destroy(c.go);
        }

        //Change chips
        LoadChipImages();

        //Shuffle
        ShuffleCards();

        //Reset variables
        cashText.text = "$" + cash.ToString();
        betText.text = "$" + bet.ToString();

        playerHand = new Hand();
        playerHand.cards = new List<Card>();
        dealerHand = new Hand();
        dealerHand.cards = new List<Card>();
    }
    void LoadChipImages()
    {
        //Decide which chips to show
        howRich = cash switch
        {
            int n when n < 1000 => 0,
            int n when n >= 1000 && n <= 1999 => 1,
            int n when n >= 2000 && n <= 4999 => 2,
            int n when n >= 5000 => 3,
            _ => 0
        };

        //Show correct chips
        for (int i = 0; i < chipImages.Length; i++)
        {
            chipImages[i].sprite = Resources.Load<Sprite>($"Images/Blackjack/Chips/{bettingOptions[howRich][i]}");
        }

    }
    void ShuffleCards()
    {
        Debug.Log("Shuffling cards");

        //Populate/Reset array
        //Sets pointer i.e. changes both lists
        //cardsInPlay = cardsInOrder;

        //Linq term makes new dataset
        cardsInPlay.cards = cardsInOrder.cards.ToList();

        //Also an option without linq:
        //cardsInPlay.cards = new List<Card>(cardsInPlay.cards);

        //Repeat 1000 times
        for (int i = 0; i < 1000; i++)
        {
            //Select two random cards
            int c1 = Random.Range(0, 52);
            int c2 = Random.Range(0, 52);

            //Switch them
            Card c1v = cardsInPlay.cards[c1];
            cardsInPlay.cards[c1] = cardsInPlay.cards[c2];
            cardsInPlay.cards[c2] = c1v;
        }

        int c = 0;
        //Check how well the shuffle worked and assign to list for use in game
        for (int i = 0; i < cardsInPlay.cards.Count; i++)
            if (cardsInPlay.cards[i] == cardsInOrder.cards[i]) c++;
        


        Debug.Log($"Number of cards in the same spot: {c}");
    }
    public void DealCards()
    {
        //Open game elements
        pregameInput.SetActive(false);
        gameElements.SetActive(true);
        gameInput.SetActive(true);


        //Deal Hand
        StartCoroutine("IDealCards");

        
    }

    public void HitCard()
    {
        if (moving) return;
        //Deal card to player
        SpawnMoveCard(true);

    }
    public void Stand()
    {
        Debug.Log("stand");
        foreach (Transform child in gameInput.transform)
        {
            child.gameObject.GetComponent<Button>().enabled = false;
        }
        //flip dealer card

        // get image, slow fade

        // add another image component, slow fade in

        // maybe new gameobject required (update hand reference)

        dealerHand.cards[1].go.GetComponent<Image>().sprite = Resources.Load<Sprite>("Images/Blackjack/Cards/" + dealerHand.cards[1].name);

        dealerText.text = dealerHand.HandValue().ToString();

        //Hit Stand logic for dealer (soft 17)

    }

    public void ChipPressed(int pos, bool less)
    {
        int value = bettingOptions[howRich][pos];
        //right click removes
        if (less)
        {
            if (bet <= value)
            {
                cash += bet;
                bet = 0;
            }
            else
            {
                bet -= value;
                cash += value;
            }
        }
        else
        {
            if (cash >= value)
            {
                bet += value;
                cash -= value;
            }

        }

        //Display
        betText.text = "$" + bet.ToString();
        cashText.text = "$" + cash.ToString();

    }
    IEnumerator IDealCards()
    {

        float speed = 1f;

        //Dealer hand
        for (int i = 0; i < 2; i++)
        {
            //Spawn card
            GameObject c = SpawnMoveCard(false, speed);

            //If second card
            if (i == 1)
            {
                //Hide value
                c.GetComponent<Image>().sprite = Resources.Load<Sprite>("Images/Blackjack/Cards/top1");
            }

            yield return new WaitForSeconds(1);
        }


        dealerText.text = "?";

        //Player hand
        for (int i = 0; i < 2; i++)
        {
            //Spawn card
            SpawnMoveCard(true, speed);

            yield return new WaitForSeconds(1);
        }

        //Set player hand value


    }

    private GameObject SpawnMoveCard(bool player, float speed = 1f)
    {
        //Make card object
        Card card = cardsInPlay.cards[0];

        card.go = Instantiate(cardPrefab, gameElements.transform);
        //Move to the deck location
        card.go.transform.localPosition = drawPile.transform.localPosition;
        card.go.transform.localRotation = drawPile.transform.localRotation;

        //Set final positions - either player or dealer deck position. Offset cards so others can be seen
        Quaternion rot = player ? playerHandRot : dealerHandRot;
        Vector3 pos = player ? playerHandPos - new Vector3(playerHand.cards.Count * -35f, 0, 0) : dealerHandPos - new Vector3(dealerHand.cards.Count * 35f, 0, 0);

        //Add card face value
        card.go.GetComponent<Image>().sprite = Resources.Load<Sprite>("Images/Blackjack/Cards/" + cardsInPlay.cards[0].name);

        //Lerp to final position at specified speed
        moving = true;
        StartCoroutine(moveCard(card.go, pos, speed, UpdateText));
        StartCoroutine(spinCard(card.go, rot, speed));

        

        //Add card to appropriate hand
        if (player)
            playerHand.AddCard(card);
        else
            dealerHand.AddCard(card);
        
        //Remove from dealing deck
        cardsInPlay.cards.RemoveAt(0);

        //Return card in case image or position needs to be changed again
        return card.go;
    }

    //Called after a card has finished moving
    void UpdateText()
    {
        moving = false;
        //Dealer
        //dealerHand.text = playerHand.HandValue().ToString();
        //Player
        playerText.text = playerHand.HandValue().ToString();

        if (playerHand.HandValue() > 21)
        {
            //Bust logic
            Stand();
        }
    }

    //Fix speed
    IEnumerator spinCard(GameObject go, Quaternion newRot, float speed)
    {
        Quaternion currentRot = go.transform.rotation;

        float counter = 0;
        while (counter < 1f)
        {
            go.transform.rotation = Quaternion.Lerp(currentRot, newRot, counter);

            counter += Time.deltaTime * speed;

            yield return null;
            
        }

        go.transform.rotation = newRot;
    }
    IEnumerator moveCard(GameObject go, Vector3 newPos, float duration, System.Action action)
    {
        Vector3 currentPos = go.transform.localPosition;

        float counter = 0;
        while (counter < duration)
        {
            counter += Time.deltaTime;
            go.transform.localPosition = Vector3.Lerp(currentPos, newPos, counter / duration);
            yield return null;
        }

        action();
    }

    public void HomeButtonPressed()
    {
        //Remove money stored in bet
        cash += bet;
        bet = 0;
        //Go back to the main menu
        Debug.Log("home button pressed");
        playCanvas.gameObject.SetActive(false);
        menuCanvas.gameObject.SetActive(true);
    }

    public void OpenOptions()
    {
        //Open options panel
        Debug.Log("option button pressed");
        optionsPanel.SetActive(true);
        
    }
    public void CloseOptions()
    {
        //Save preferences over restarts
        PlayerPrefs.SetFloat("volume", vol);
        PlayerPrefs.SetInt("bettingEnabled", bettingToggle.isOn ? 1 : 0);
        PlayerPrefs.SetInt("showHandValue", handValueToggle.isOn ? 1 : 0);

        //Disable panel
        optionsPanel.SetActive(false);
    }

    public void ChangeVolume(float sliderValue)
    {
        //Change actual game volume - Log used to match volume scaling (not linear)
        audioMixer.SetFloat("masterVol", Mathf.Log10(sliderValue) * 20);

        //Update internal variable
        vol = sliderValue;

        //Display volume as percentage
        volumeText.text = Mathf.RoundToInt(sliderValue * 100).ToString() + "%";
    }

    //***FIX**** Only partially working
    public void MuteAudio(bool mute)
    {
        Debug.Log(mute);

        if (mute)
        {
            audioMixer.SetFloat("masterVol", 0);
            volumeText.text = "0%";
            volSlider.value = 0;
        }
        else
        {
            audioMixer.SetFloat("masterVol", Mathf.Log10(vol) * 20);
            volSlider.value = vol;
            volumeText.text = Mathf.RoundToInt(vol * 100).ToString() + "%";
        }
    }

    private void OnApplicationQuit()
    {
        PlayerPrefs.SetInt("cash", cash);
    }
    public void MainMenu()
    {
        PlayerPrefs.SetInt("cash", cash);
        //Usually called when exiting program (OnApplicationQuit), however preferences would be lost as scene is unloaded and the above method is not called.
        PlayerPrefs.Save();
        SceneManager.LoadScene("Main");
    }
}
[System.Serializable]
public struct Card
{
    //Elements
    public string denomination;
    public string suit;
    public int value;
    public GameObject go;
    public readonly string name => denomination + suit;
    // Operators

    //Override default Equals operation and run custom implementation (used in form card.Equals(c))
    public override bool Equals(object obj) => obj is Card c && Equals(c);

    //Custom equals implementation
    public bool Equals(Card c)
    {
        //Null protection
        if(c == null) return false;
        //If all important values are the same, return true, if not return false
        return (denomination == c.denomination) && (suit == c.suit) && (go == c.go);
    }

    //Neccesary for internal calulations - VS encouraged (implementation from MS C# docs)
    public override int GetHashCode() => (denomination, suit, go).GetHashCode();

    //Direct operator calls to custom equals implementations
    public static bool operator ==(Card c1, Card c2) => c1.Equals(c2);

    //Inverse
    public static bool operator !=(Card c1, Card c2) => !(c1 == c2);
}
[System.Serializable]
public struct Hand {
    //Elements
    public string name;
    public List<Card> cards;

    public void AddCard(Card c)
    {
        // Override add function for list and determine card value
        // Respect standard ruls for aces and picture cards
        
        //Null protection
        if (c == null) return;

        if (int.TryParse(c.denomination, out c.value)) { }
        else if (c.denomination == "A")
        {
            //Handle ace value
            if (this.HandValue() > 11) c.value = 1;
            else c.value = 11;
        }
        else
        {
            //Other picture cards
            c.value = 10;
        }

        //Change Ace value if over
        if(this.HandValue() > 21)
        {
            for (int i = 0; i < cards.Count; i++)
            {
                if (cards[i].value == 11)
                {
                    Card card = cards[i];
                    card.value = 1;
                    cards.RemoveAt(i);
                    cards.Add(card);
                }
            }
        }

        cards.Add(c);
    }
    //Determine Hand value
    public int HandValue()
    {
        int value = 0;
        foreach (Card card in cards)
        {
            value += card.value;
        }
        return value;
    }
}

